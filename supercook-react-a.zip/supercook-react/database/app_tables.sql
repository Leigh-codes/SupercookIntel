-- Extra tables the website/API needs on top of supercook_db.sql (accounts, saved pantry, favorites).
-- Safe to run more than once. Applied automatically by:  npm run db:setup
-- (No CREATE DATABASE / USE here: setup-db.js selects the database named in .env.)

CREATE TABLE IF NOT EXISTS users (
  user_id       INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username      VARCHAR(30)  NOT NULL,
  email         VARCHAR(120) NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_admin      TINYINT(1)   NOT NULL DEFAULT 0,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_users_username (username),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A logged-in user's saved pantry
CREATE TABLE IF NOT EXISTS user_pantry (
  user_id       INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED NOT NULL,
  added_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, ingredient_id),
  KEY idx_user_pantry_ingredient (ingredient_id),
  CONSTRAINT fk_user_pantry_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_user_pantry_ingredient FOREIGN KEY (ingredient_id)
    REFERENCES ingredients (ingredient_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_favorites (
  user_id    INT UNSIGNED NOT NULL,
  recipe_id  INT UNSIGNED NOT NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, recipe_id),
  KEY idx_user_favorites_recipe (recipe_id),
  CONSTRAINT fk_user_favorites_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_user_favorites_recipe FOREIGN KEY (recipe_id)
    REFERENCES recipes (recipe_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
