-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2026 at 04:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supercook_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `ingredient_id` int(10) UNSIGNED NOT NULL,
  `subcategory_id` int(10) UNSIGNED NOT NULL,
  `ingredient_name` varchar(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `ingredients`:
--   `subcategory_id`
--       `ingredient_subcategories` -> `subcategory_id`
--

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`ingredient_id`, `subcategory_id`, `ingredient_name`) VALUES
(1, 5, 'Chicken'),
(2, 1, 'Beef'),
(3, 2, 'Pork'),
(4, 3, 'Lamb'),
(5, 6, 'Salmon'),
(6, 6, 'Tilapia'),
(7, 6, 'Canned tuna'),
(8, 7, 'Shrimp'),
(9, 8, 'Squid'),
(10, 9, 'Chicken liver'),
(11, 10, 'Bacon'),
(12, 12, 'Eggs'),
(13, 17, 'Cow\'s milk'),
(14, 20, 'Heavy cream'),
(15, 21, 'Butter'),
(16, 23, 'Cheddar cheese'),
(17, 22, 'Cream cheese'),
(18, 25, 'Plain yogurt'),
(19, 27, 'Condensed milk'),
(20, 28, 'Evaporated milk'),
(21, 31, 'Soy milk'),
(22, 32, 'Oat milk'),
(23, 33, 'Almond milk'),
(24, 34, 'Coconut milk'),
(25, 38, 'Plant-based butter'),
(26, 40, 'Plant-based yogurt'),
(27, 41, 'Tofu'),
(28, 42, 'Chickpeas'),
(29, 43, 'Lentils'),
(30, 44, 'Black beans'),
(31, 45, 'Peanuts'),
(32, 46, 'Cashews'),
(33, 47, 'Sesame seeds'),
(34, 48, 'Peanut butter'),
(35, 50, 'Spinach'),
(36, 51, 'Cabbage'),
(37, 52, 'Carrots'),
(38, 53, 'Potatoes'),
(39, 53, 'Sweet potatoes'),
(40, 54, 'Onions'),
(41, 54, 'Garlic'),
(42, 56, 'Tomatoes'),
(43, 57, 'Bell peppers'),
(44, 56, 'Eggplant'),
(45, 58, 'Zucchini'),
(46, 59, 'Green peas'),
(47, 60, 'Button mushrooms'),
(48, 61, 'Bean sprouts'),
(49, 62, 'Nori'),
(50, 63, 'Frozen mixed vegetables'),
(51, 64, 'Canned corn'),
(52, 51, 'Broccoli'),
(53, 56, 'Cucumber'),
(54, 69, 'Apples'),
(55, 66, 'Mangoes'),
(56, 66, 'Bananas'),
(57, 65, 'Calamansi'),
(58, 65, 'Lemons'),
(59, 65, 'Limes'),
(60, 66, 'Pineapple'),
(61, 67, 'Strawberries'),
(62, 68, 'Watermelon'),
(63, 72, 'Raisins'),
(64, 73, 'Apple puree'),
(65, 74, 'Orange juice'),
(66, 75, 'Rice'),
(67, 80, 'All-purpose flour'),
(68, 80, 'Bread flour'),
(69, 82, 'Pasta'),
(70, 83, 'Egg noodles'),
(71, 77, 'Rolled oats'),
(72, 78, 'Cornmeal'),
(73, 79, 'Quinoa'),
(74, 81, 'Cornstarch'),
(75, 84, 'White bread'),
(76, 85, 'Tortillas'),
(77, 86, 'Spring roll wrappers'),
(78, 87, 'Breadcrumbs'),
(79, 83, 'Rice noodles'),
(80, 91, 'Ginger'),
(81, 89, 'Basil'),
(82, 89, 'Cilantro'),
(83, 89, 'Parsley'),
(84, 90, 'Spring onions'),
(85, 91, 'Lemongrass'),
(86, 92, 'Curry leaves'),
(87, 95, 'Black pepper'),
(88, 95, 'Paprika'),
(89, 95, 'Cumin'),
(90, 94, 'Cinnamon'),
(91, 96, 'Chili flakes'),
(92, 97, 'Curry powder'),
(93, 97, 'Five-spice powder'),
(94, 98, 'Garlic powder'),
(95, 99, 'Cooking oil'),
(96, 100, 'Olive oil'),
(97, 101, 'Sesame oil'),
(98, 102, 'Lard'),
(99, 105, 'Soy sauce'),
(100, 106, 'Fish sauce'),
(101, 107, 'Tomato paste'),
(102, 108, 'Sriracha'),
(103, 109, 'Red curry paste'),
(104, 110, 'Mayonnaise'),
(105, 111, 'Mustard'),
(106, 106, 'Oyster sauce'),
(107, 113, 'White vinegar'),
(108, 115, 'Rice vinegar'),
(109, 114, 'Apple cider vinegar'),
(110, 116, 'Calamansi juice'),
(111, 117, 'Tamarind paste'),
(112, 119, 'Sugar'),
(113, 119, 'Brown sugar'),
(114, 120, 'Powdered sugar'),
(115, 121, 'Honey'),
(116, 122, 'Maple syrup'),
(117, 123, 'Molasses'),
(118, 126, 'Baking powder'),
(119, 126, 'Baking soda'),
(120, 127, 'Instant yeast'),
(121, 128, 'Cocoa powder'),
(122, 128, 'Dark chocolate'),
(123, 129, 'Vanilla extract'),
(124, 130, 'Gelatin'),
(125, 135, 'Chicken broth'),
(126, 136, 'Beef broth'),
(127, 137, 'Vegetable broth'),
(128, 134, 'Water'),
(129, 143, 'Kimchi'),
(130, 143, 'Sauerkraut'),
(131, 144, 'Miso'),
(132, 142, 'Pickles'),
(133, 147, 'Green olives'),
(134, 147, 'Capers'),
(135, 148, 'Instant ramen noodles'),
(136, 131, 'Pancake mix'),
(137, 139, 'Coconut cream'),
(138, 152, 'Adobo seasoning mix'),
(139, 158, 'Toasted sesame seeds'),
(140, 160, 'Sea salt'),
(141, 157, 'Lime zest'),
(142, 72, 'Dried mango'),
(143, 162, 'Pandan leaves'),
(144, 162, 'Banana ketchup'),
(145, 163, 'Dried shrimp'),
(146, 163, 'Gochujang'),
(147, 164, 'Garam masala'),
(148, 165, 'Sumac'),
(149, 166, 'Chipotle in adobo'),
(150, 167, 'Capellini');

-- --------------------------------------------------------

--
-- Table structure for table `ingredient_aliases`
--

CREATE TABLE `ingredient_aliases` (
  `alias_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED NOT NULL,
  `alias_name` varchar(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `ingredient_aliases`:
--   `ingredient_id`
--       `ingredients` -> `ingredient_id`
--

--
-- Dumping data for table `ingredient_aliases`
--

INSERT INTO `ingredient_aliases` (`alias_id`, `ingredient_id`, `alias_name`) VALUES
(1, 84, 'Scallion'),
(2, 84, 'Green onion'),
(3, 84, 'Green onions'),
(4, 82, 'Coriander leaves'),
(5, 44, 'Aubergine'),
(6, 45, 'Courgette'),
(7, 28, 'Garbanzos'),
(8, 28, 'Chick pea'),
(9, 74, 'Corn starch'),
(10, 67, 'All-purpose wheat flour'),
(11, 82, 'Coriander seed leaves'),
(12, 57, 'Calamondin'),
(13, 21, 'Soya milk');

-- --------------------------------------------------------

--
-- Table structure for table `ingredient_categories`
--

CREATE TABLE `ingredient_categories` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `ingredient_categories`:
--

--
-- Dumping data for table `ingredient_categories`
--

INSERT INTO `ingredient_categories` (`category_id`, `category_name`) VALUES
(1, 'Animal Proteins'),
(15, 'Baking and Dessert Ingredients'),
(3, 'Dairy Products'),
(10, 'Dried Spices and Spice Blends'),
(2, 'Eggs and Egg Products'),
(17, 'Fermented, Pickled and Preserved Foods'),
(7, 'Fruits'),
(19, 'Garnishes and Finishing Ingredients'),
(8, 'Grains, Flours, Starches and Grain Products'),
(9, 'Herbs and Fresh Aromatics'),
(16, 'Liquids, Broths and Cooking Bases'),
(11, 'Oils, Fats and Shortening'),
(18, 'Packaged and Convenience Ingredients'),
(5, 'Plant Proteins, Legumes, Nuts and Seeds'),
(4, 'Plant-Based Dairy Alternatives'),
(12, 'Sauces, Condiments and Pastes'),
(20, 'Specialty and Regional Ingredients'),
(14, 'Sweeteners and Syrups'),
(6, 'Vegetables'),
(13, 'Vinegars, Acids and Souring Agents');

-- --------------------------------------------------------

--
-- Table structure for table `ingredient_subcategories`
--

CREATE TABLE `ingredient_subcategories` (
  `subcategory_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `subcategory_name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `ingredient_subcategories`:
--   `category_id`
--       `ingredient_categories` -> `category_id`
--

--
-- Dumping data for table `ingredient_subcategories`
--

INSERT INTO `ingredient_subcategories` (`subcategory_id`, `category_id`, `subcategory_name`) VALUES
(1, 1, 'Beef'),
(7, 1, 'Crustaceans'),
(6, 1, 'Fish'),
(4, 1, 'Goat'),
(3, 1, 'Lamb'),
(8, 1, 'Mollusks'),
(9, 1, 'Organ meats'),
(11, 1, 'Other seafood'),
(2, 1, 'Pork'),
(5, 1, 'Poultry'),
(10, 1, 'Processed meats'),
(12, 2, 'Chicken eggs'),
(16, 2, 'Dried egg products'),
(13, 2, 'Duck eggs'),
(15, 2, 'Liquid egg products'),
(14, 2, 'Quail eggs'),
(24, 3, 'Blue cheeses'),
(21, 3, 'Butter'),
(27, 3, 'Condensed milk'),
(17, 3, 'Cow\'s milk'),
(20, 3, 'Cream'),
(28, 3, 'Evaporated milk'),
(26, 3, 'Fermented dairy'),
(22, 3, 'Fresh cheeses'),
(18, 3, 'Goat\'s milk'),
(23, 3, 'Hard cheeses'),
(29, 3, 'Milk powder'),
(19, 3, 'Sheep\'s milk'),
(30, 3, 'Whey'),
(25, 3, 'Yogurt'),
(33, 4, 'Almond milk'),
(34, 4, 'Coconut milk'),
(32, 4, 'Oat milk'),
(36, 4, 'Other plant milks'),
(38, 4, 'Plant-based butter'),
(39, 4, 'Plant-based cheese'),
(37, 4, 'Plant-based cream'),
(40, 4, 'Plant-based yogurt'),
(35, 4, 'Rice milk'),
(31, 4, 'Soy milk'),
(44, 5, 'Beans and peas'),
(42, 5, 'Chickpeas'),
(43, 5, 'Lentils'),
(48, 5, 'Nut and seed butters'),
(45, 5, 'Peanuts'),
(47, 5, 'Seeds'),
(49, 5, 'Textured plant protein'),
(41, 5, 'Tofu and soy foods'),
(46, 5, 'Tree nuts'),
(54, 6, 'Bulbs'),
(51, 6, 'Cabbage family vegetables'),
(64, 6, 'Canned vegetables'),
(57, 6, 'Fresh peppers'),
(63, 6, 'Frozen vegetables'),
(56, 6, 'Fruiting vegetables'),
(50, 6, 'Leafy greens'),
(59, 6, 'Legumes'),
(60, 6, 'Mushrooms'),
(52, 6, 'Root vegetables'),
(62, 6, 'Sea vegetables'),
(61, 6, 'Sprouts'),
(58, 6, 'Squash and gourds'),
(55, 6, 'Stems'),
(53, 6, 'Tubers'),
(67, 7, 'Berries'),
(65, 7, 'Citrus'),
(72, 7, 'Dried fruits'),
(74, 7, 'Fruit juices'),
(73, 7, 'Fruit purees'),
(71, 7, 'Grapes'),
(68, 7, 'Melons'),
(69, 7, 'Pome fruits'),
(70, 7, 'Stone fruits'),
(66, 7, 'Tropical fruits'),
(84, 8, 'Bread'),
(87, 8, 'Breadcrumbs'),
(78, 8, 'Corn'),
(85, 8, 'Flatbreads'),
(80, 8, 'Flours'),
(83, 8, 'Noodles'),
(77, 8, 'Oats'),
(88, 8, 'Other grains'),
(82, 8, 'Pasta'),
(79, 8, 'Pseudocereals'),
(75, 8, 'Rice'),
(81, 8, 'Starches'),
(76, 8, 'Wheat grains'),
(86, 8, 'Wrappers'),
(90, 9, 'Alliums'),
(92, 9, 'Citrus leaves and aromatic leaves'),
(89, 9, 'Fresh herbs'),
(91, 9, 'Ginger-family aromatics'),
(93, 9, 'Other fresh aromatics'),
(96, 10, 'Chilies and dried peppers'),
(98, 10, 'Dried aromatic seasonings'),
(95, 10, 'Ground spices'),
(97, 10, 'Spice blends'),
(94, 10, 'Whole spices'),
(102, 11, 'Animal fats'),
(104, 11, 'Cooking sprays'),
(101, 11, 'Nut and seed oils'),
(100, 11, 'Olive oils'),
(103, 11, 'Shortening'),
(99, 11, 'Vegetable oils'),
(108, 12, 'Chili sauces'),
(109, 12, 'Cooking pastes'),
(106, 12, 'Fish and seafood sauces'),
(110, 12, 'Mayonnaise and creamy condiments'),
(111, 12, 'Mustard and horseradish'),
(112, 12, 'Other savory condiments'),
(105, 12, 'Soy-based sauces'),
(107, 12, 'Tomato sauces and pastes'),
(113, 13, 'Cane and grain vinegars'),
(116, 13, 'Citrus juice'),
(114, 13, 'Fruit vinegars'),
(118, 13, 'Other food acids'),
(115, 13, 'Rice vinegar'),
(117, 13, 'Tamarind and sour fruit'),
(124, 14, 'Coconut and palm sweeteners'),
(121, 14, 'Honey'),
(122, 14, 'Maple and tree syrups'),
(123, 14, 'Molasses'),
(120, 14, 'Powdered sugar'),
(125, 14, 'Sugar alternatives'),
(119, 14, 'White and brown sugars'),
(126, 15, 'Baking powder and soda'),
(128, 15, 'Cocoa and chocolate'),
(133, 15, 'Decorations and sprinkles'),
(131, 15, 'Dessert mixes'),
(130, 15, 'Gelatin and setting agents'),
(132, 15, 'Puddings and custards'),
(129, 15, 'Vanilla and extracts'),
(127, 15, 'Yeast'),
(136, 16, 'Beef broth'),
(135, 16, 'Chicken broth'),
(139, 16, 'Coconut liquids'),
(138, 16, 'Fish stock'),
(141, 16, 'Other cooking bases'),
(137, 16, 'Vegetable broth'),
(134, 16, 'Water'),
(140, 16, 'Wine and cooking alcohol'),
(146, 17, 'Cured and salted ingredients'),
(144, 17, 'Fermented soy foods'),
(143, 17, 'Fermented vegetables'),
(147, 17, 'Olives and capers'),
(142, 17, 'Pickled vegetables'),
(145, 17, 'Preserved fish and seafood'),
(150, 18, 'Canned meals and fillings'),
(153, 18, 'Frozen prepared foods'),
(148, 18, 'Instant noodles'),
(149, 18, 'Ready-made pastry'),
(154, 18, 'Ready-made sauces'),
(152, 18, 'Seasoning packets'),
(151, 18, 'Soup mixes'),
(157, 19, 'Citrus zest'),
(159, 19, 'Crispy toppings'),
(160, 19, 'Finishing salts'),
(155, 19, 'Fresh garnish herbs'),
(156, 19, 'Scallions and finishing alliums'),
(161, 19, 'Sesame and aromatic toppings'),
(158, 19, 'Toasted nuts and seeds'),
(163, 20, 'East and Southeast Asian specialty ingredients'),
(167, 20, 'European specialty ingredients'),
(162, 20, 'Filipino regional ingredients'),
(166, 20, 'Latin American specialty ingredients'),
(165, 20, 'Middle Eastern specialty ingredients'),
(168, 20, 'Other specialty ingredients'),
(164, 20, 'South Asian specialty ingredients');

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `recipe_name` varchar(180) NOT NULL,
  `meal_type` varchar(60) DEFAULT NULL,
  `cuisine_type` varchar(100) DEFAULT NULL,
  `recipe_minutes` smallint(5) UNSIGNED NOT NULL DEFAULT 0 COMMENT 'total minutes to make the recipe',
  `servings` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `image_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `source_name` varchar(120) DEFAULT NULL,
  `source_url` varchar(500) DEFAULT NULL,
  `rating` tinyint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `recipes`:
--

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`recipe_id`, `recipe_name`, `meal_type`, `cuisine_type`, `recipe_minutes`, `servings`, `image_url`, `created_at`, `source_name`, `source_url`, `rating`) VALUES
(1, 'Filipino Chicken Adobo', 'Dinner', 'Filipino', 50, 4, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(2, 'Garlic Fried Rice', 'Breakfast', 'Filipino', 20, 2, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(3, 'Tomato Basil Pasta', 'Lunch', 'Italian', 30, 3, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(4, 'Vegetable Tofu Stir-Fry', 'Dinner', 'Chinese-inspired', 30, 3, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(5, 'Chickpea Coconut Curry', 'Dinner', 'Indian-inspired', 35, 4, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(6, 'Mango Oat Yogurt Bowl', 'Breakfast', 'Modern', 8, 1, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(7, 'Salmon with Lemon and Herbs', 'Dinner', 'Western', 22, 2, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL),
(8, 'Banana Pancakes', 'Breakfast', 'American-inspired', 25, 2, NULL, '2026-10-10 18:11:22', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED NOT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `is_optional` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `recipe_ingredients`:
--   `ingredient_id`
--       `ingredients` -> `ingredient_id`
--   `recipe_id`
--       `recipes` -> `recipe_id`
--

--
-- Dumping data for table `recipe_ingredients`
--

INSERT INTO `recipe_ingredients` (`recipe_id`, `ingredient_id`, `quantity`, `unit`, `is_optional`) VALUES
(1, 1, 1.00, 'kg', 0),
(1, 41, 6.00, 'cloves', 0),
(1, 66, 2.00, 'cups', 1),
(1, 80, 1.00, 'tbsp', 1),
(1, 87, 1.00, 'tsp', 0),
(1, 99, 0.50, 'cup', 0),
(1, 107, 0.50, 'cup', 0),
(1, 128, 1.00, 'cup', 0),
(2, 41, 5.00, 'cloves', 0),
(2, 66, 3.00, 'cups cooked', 0),
(2, 84, 2.00, 'tbsp', 1),
(2, 87, 0.25, 'tsp', 1),
(2, 95, 2.00, 'tbsp', 0),
(2, 99, 1.00, 'tbsp', 1),
(3, 41, 3.00, 'cloves', 0),
(3, 69, 250.00, 'g', 0),
(3, 81, 0.25, 'cup', 0),
(3, 87, 0.25, 'tsp', 1),
(3, 96, 2.00, 'tbsp', 0),
(3, 101, 2.00, 'tbsp', 0),
(3, 128, 1.00, 'cup', 1),
(4, 27, 300.00, 'g', 0),
(4, 36, 2.00, 'cups', 0),
(4, 37, 1.00, 'medium', 0),
(4, 43, 1.00, 'medium', 0),
(4, 66, 2.00, 'cups cooked', 1),
(4, 95, 1.00, 'tbsp', 0),
(4, 99, 2.00, 'tbsp', 0),
(5, 24, 400.00, 'ml', 0),
(5, 28, 2.00, 'cups cooked', 0),
(5, 40, 1.00, 'medium', 0),
(5, 66, 2.00, 'cups cooked', 1),
(5, 87, 0.25, 'tsp', 1),
(5, 92, 2.00, 'tsp', 0),
(5, 95, 1.00, 'tbsp', 0),
(6, 18, 1.00, 'cup', 0),
(6, 55, 1.00, 'cup diced', 0),
(6, 56, 1.00, 'medium', 0),
(6, 71, 0.50, 'cup', 0),
(6, 115, 1.00, 'tsp', 1),
(7, 5, 2.00, 'fillets', 0),
(7, 83, 1.00, 'tbsp', 0),
(7, 87, 0.25, 'tsp', 0),
(7, 96, 1.00, 'tbsp', 0),
(7, 110, 1.00, 'tbsp', 0),
(7, 140, 0.25, 'tsp', 0),
(8, 12, 1.00, 'large', 0),
(8, 13, 0.50, 'cup', 0),
(8, 56, 2.00, 'medium', 0),
(8, 67, 1.00, 'cup', 0),
(8, 95, 1.00, 'tsp', 0),
(8, 115, 1.00, 'tbsp', 1),
(8, 118, 1.00, 'tsp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

-- --------------------------------------------------------

--
-- Table structure for table `user_favorites`
--

CREATE TABLE `user_favorites` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `recipe_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `user_favorites`:
--   `recipe_id`
--       `recipes` -> `recipe_id`
--   `user_id`
--       `users` -> `user_id`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_pantry`
--

CREATE TABLE `user_pantry` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `ingredient_id` int(10) UNSIGNED NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `user_pantry`:
--   `ingredient_id`
--       `ingredients` -> `ingredient_id`
--   `user_id`
--       `users` -> `user_id`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`ingredient_id`),
  ADD UNIQUE KEY `uq_ingredients_name` (`ingredient_name`),
  ADD KEY `idx_ingredients_subcategory` (`subcategory_id`);

--
-- Indexes for table `ingredient_aliases`
--
ALTER TABLE `ingredient_aliases`
  ADD PRIMARY KEY (`alias_id`),
  ADD UNIQUE KEY `uq_ingredient_aliases_name` (`alias_name`),
  ADD KEY `idx_ingredient_aliases_ingredient` (`ingredient_id`);

--
-- Indexes for table `ingredient_categories`
--
ALTER TABLE `ingredient_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `uq_ingredient_categories_name` (`category_name`);

--
-- Indexes for table `ingredient_subcategories`
--
ALTER TABLE `ingredient_subcategories`
  ADD PRIMARY KEY (`subcategory_id`),
  ADD UNIQUE KEY `uq_subcategory_category_name` (`category_id`,`subcategory_name`),
  ADD KEY `idx_subcategories_category` (`category_id`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`recipe_id`),
  ADD UNIQUE KEY `uq_recipes_name` (`recipe_name`),
  ADD KEY `idx_recipes_meal_type` (`meal_type`),
  ADD KEY `idx_recipes_cuisine_type` (`cuisine_type`),
  ADD KEY `idx_recipes_recipe_minutes` (`recipe_minutes`),
  ADD KEY `idx_recipes_created_at` (`created_at`);

--
-- Indexes for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`recipe_id`,`ingredient_id`),
  ADD KEY `idx_recipe_ingredients_ingredient` (`ingredient_id`),
  ADD KEY `idx_recipe_ingredients_required` (`recipe_id`,`is_optional`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_username` (`username`),
  ADD UNIQUE KEY `uq_users_email` (`email`);

--
-- Indexes for table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`user_id`,`recipe_id`),
  ADD KEY `idx_user_favorites_recipe` (`recipe_id`);

--
-- Indexes for table `user_pantry`
--
ALTER TABLE `user_pantry`
  ADD PRIMARY KEY (`user_id`,`ingredient_id`),
  ADD KEY `idx_user_pantry_ingredient` (`ingredient_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `ingredient_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `ingredient_aliases`
--
ALTER TABLE `ingredient_aliases`
  MODIFY `alias_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `ingredient_categories`
--
ALTER TABLE `ingredient_categories`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `ingredient_subcategories`
--
ALTER TABLE `ingredient_subcategories`
  MODIFY `subcategory_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=257;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `recipe_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD CONSTRAINT `fk_ingredients_subcategory` FOREIGN KEY (`subcategory_id`) REFERENCES `ingredient_subcategories` (`subcategory_id`) ON UPDATE CASCADE;

--
-- Constraints for table `ingredient_aliases`
--
ALTER TABLE `ingredient_aliases`
  ADD CONSTRAINT `fk_ingredient_aliases_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`ingredient_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ingredient_subcategories`
--
ALTER TABLE `ingredient_subcategories`
  ADD CONSTRAINT `fk_subcategories_category` FOREIGN KEY (`category_id`) REFERENCES `ingredient_categories` (`category_id`) ON UPDATE CASCADE;

--
-- Constraints for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD CONSTRAINT `fk_recipe_ingredients_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`ingredient_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_recipe_ingredients_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `fk_user_favorites_recipe` FOREIGN KEY (`recipe_id`) REFERENCES `recipes` (`recipe_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_pantry`
--
ALTER TABLE `user_pantry`
  ADD CONSTRAINT `fk_user_pantry_ingredient` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`ingredient_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_pantry_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;


--
-- Metadata
--
USE `phpmyadmin`;

--
-- Metadata for table ingredients
--

--
-- Metadata for table ingredient_aliases
--

--
-- Metadata for table ingredient_categories
--

--
-- Metadata for table ingredient_subcategories
--

--
-- Metadata for table recipes
--

--
-- Metadata for table recipe_ingredients
--

--
-- Metadata for table users
--

--
-- Metadata for table user_favorites
--

--
-- Metadata for table user_pantry
--

--
-- Metadata for database supercook_db
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
