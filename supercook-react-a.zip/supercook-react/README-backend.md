# SuperCook: database, API and outside recipe search

The website is `src/`. The API is `server/`. The database files are `database/`.

## Run it (Windows PowerShell, inside the folder with package.json; MySQL started in XAMPP or Laragon)

```powershell
npm install
npm run db:setup       # once (safe to repeat): creates database "supercook_db", loads database/supercook_db.sql (only if the database is still empty),
                       # makes sure the account tables and recipe columns exist, converts old prep/cook times
npm run api            # starts the API on http://localhost:3001   (keep this window open)
npm run dev            # in a SECOND window: starts the website
```

Check in the browser: http://localhost:3001/api/health  (should say `"database":"connected"`),
then http://localhost:3001/api/recipes and http://localhost:3001/api/meta

`.env` must say `DB_NAME=supercook_db` (already set). XAMPP default is user `root`, empty password.
If your MySQL has a password, put it in `DB_PASSWORD`.

## What the website shows comes from the database

Nothing is hard-coded in the website any more. On load it calls `/api/recipes` and `/api/meta` and builds:
the pantry list (ingredients grouped by their category name), Meal Type, Cuisines, the Max Ingredients slider
(top = most required ingredients in any recipe), the Recipe Time slider (top = longest recipe), and the Rating
buttons (only ratings that exist). Add a recipe or ingredient in MySQL and it appears after a page refresh.
Only the Exclude filter is a free ingredient search. If the API/database is off, the page says so instead of showing fake data.

## How the database is used

| Table (from supercook_db.sql) | Used for |
|---|---|
| ingredient_categories / ingredient_subcategories / ingredients | the pantry sidebar (grouped by category) |
| ingredient_aliases | typing "scallion" finds *Spring onions*; the API also understands aliases in a search |
| recipes / recipe_ingredients | recipe search, quantities, optional ingredients |
| users, user_pantry, user_favorites (from app_tables.sql) | accounts, saved pantry, favorites |

`npm run db:setup` also adds `recipes.source_name`, `recipes.source_url` and `recipes.rating` (NULL = not rated) if they are missing,
and makes recipe names unique. `recipes.recipe_minutes` is the recipe time: the total minutes to make the recipe
(it replaces the old prep_minutes + cook_minutes; an older database is converted automatically, adding the two together).

Matching rules: only **required** ingredients count as "matched" (optional ones are shown but never counted);
recipes are ordered by the share of required ingredients you have. Excluding an ingredient also hides recipes
that list it as optional. The rating filter hides unrated recipes.

## The outside recipe API

`GET /api/search` looks in your database first. If fewer than 8 recipes match, it asks an outside service and
merges the results (same shape as your own recipes, with a link back to the source). Results are remembered
for `EXTERNAL_CACHE_HOURS` (default 1). If the service is down or blocked, search quietly returns your own recipes.

| `EXTERNAL_PROVIDER` in .env | What happens |
|---|---|
| `auto` (default) | Spoonacular if `SPOONACULAR_KEY` is set, otherwise TheMealDB |
| `themealdb` | TheMealDB, no signup. Uses their public test key `1`: fine for development. For a public site get your own key and set `THEMEALDB_KEY`. No cooking time or rating in their data. |
| `spoonacular` | needs a free key from https://spoonacular.com/food-api in `SPOONACULAR_KEY`. Includes time and score. |
| `none` | database recipes only |

Test it:  `npm run api:check`  or  `npm run api:check -- Chicken Garlic`
`/api/health` shows which provider is active (`externalSearch`).

## Accounts, pantry and favorites

The login form now talks to the API (register with username + email + password, log in with email).
While logged in, your pantry is saved to your account and favorites are saved for recipes that are in your
database; favorites of outside recipes stay in this browser. On login, what is in the browser and in the account is merged.

Make an admin (can add/edit/delete recipes through the API):  `node server/make-admin.js <username>`

## Endpoints (all start with /api)

| Method | Path | Login | What it does |
|---|---|---|---|
| GET | /health | no | API, database and outside-search status |
| POST | /register | no | `{ username, email, password }` -> `{ username, token }` |
| POST | /login | no | `{ username (or email), password }` -> `{ username, token }` |
| GET | /me | yes | who am I |
| GET | /recipes, /recipes/:id | no | recipes with ingredients, quantities |
| GET | /meta | no | `{ meals, cuisines, ingredients (by category), aliases }` |
| GET | /search | no | `?pantry=Chicken,Garlic&exclude=&meal=&cuisine=&maxIng=&time=&rating=&external=0` -> `[{ r, have }]` |
| POST, PUT, DELETE | /recipes, /recipes/:id | admin | see below |
| GET, PUT, DELETE | /pantry | yes | read / replace (`{ items: [...] }`) / empty the saved pantry |
| POST, DELETE | /pantry/:name | yes | add / remove one ingredient |
| GET | /favorites | yes | favorite recipe names |
| POST, DELETE | /favorites/:name | yes | add / remove a favorite |

Admin recipe body (POST, or PUT with every field):

```json
{ "name": "Garlic Rice", "meal": "Dinner", "cuisine": "Filipino",
  "ingredients": [ { "name": "Garlic", "quantity": 3, "unit": "cloves" }, { "name": "Rice" }, { "name": "Spring onions", "optional": true } ],
  "time": 15, "servings": 2, "image_url": "", "source_name": "", "source_url": "", "rating": 4 }
```
Ingredient names that don't exist yet are added under *Other specialty ingredients*.

Send the token as `Authorization: Bearer <token>`.

## Before putting it online

- Make a new `JWT_SECRET` (command in `.env.example`); `.env` is in `.gitignore`.
- Set `CLIENT_ORIGIN` to your website's address, and `VITE_API_URL` when building the website.
- Get your own TheMealDB / Spoonacular key and check their terms before raising `EXTERNAL_CACHE_HOURS`.
