import { useState } from 'react'
import { login, register } from '../api.js'

// Login and Register share one form; `mode` decides which one it is.
// Talks to the API; calls onSubmit(username) once the account is logged in.
export default function AuthForm({ mode, onSubmit, onSwitch }) {
  const reg = mode === 'register'
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function handleSubmit() {
    if (busy) return
    const em = email.trim()
    const un = username.trim()
    if (reg && (un.length < 2 || un.length > 30)) return setError('Username must be 2 to 30 characters.')
    if (!/^\S+@\S+\.\S+$/.test(em)) return setError('Enter a valid email address.')
    if (password.length < 6) return setError('Password must be at least 6 characters.')

    setBusy(true)
    setError('')
    try {
      const name = reg ? await register(un, em, password) : await login(em, password)
      onSubmit(name)
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div
      className="auth"
      role="form"
      aria-label={reg ? 'Register' : 'Log in'}
      onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
    >
      <h2>{reg ? 'Register' : 'Log In'}</h2>

      {reg && (
        <div className="field">
          <label htmlFor="username">Username:</label>
          <input id="username" autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
      )}
      <div className="field">
        <label htmlFor="email">Email Address:</label>
        <input id="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <div className="field">
        <label htmlFor="password">Password:</label>
        <input
          id="password"
          type="password"
          autoComplete={reg ? 'new-password' : 'current-password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <p className="err" aria-live="polite">{error}</p>
      <button className="btn" onClick={handleSubmit} disabled={busy}>
        {busy ? 'Please wait…' : reg ? 'Register' : 'Log In'}
      </button>

      <p className="swap">
        {reg ? 'Already Have An Account? ' : 'No Account Yet? '}
        <button onClick={onSwitch}>{reg ? 'Log In' : 'Register'}</button>
      </p>
    </div>
  )
}
