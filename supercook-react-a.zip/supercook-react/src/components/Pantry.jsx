import { useState } from 'react'
import { useCatalog } from '../catalog.jsx'

// The green sidebar: search box + ingredient buttons grouped by category
export default function Pantry({ pantry, onToggle, onClear }) {
  const { ingredients, aliases, status, error } = useCatalog()
  const [query, setQuery] = useState('')
  const [collapsed, setCollapsed] = useState(false)

  const q = query.toLowerCase()
  // Keep only matching ingredients, and drop categories that end up empty
  const categories = Object.entries(ingredients)
    .map(([name, items]) => [
      name,
      items.filter((i) => i.toLowerCase().includes(q) || (aliases[i] || []).some((a) => a.toLowerCase().includes(q))),
    ])
    .filter(([, items]) => items.length)

  return (
    <aside className={collapsed ? 'min' : ''}>
      <div className="side-top">
        <button
          className="icon-btn"
          id="toggle"
          aria-label={collapsed ? 'Expand pantry' : 'Collapse pantry'}
          onClick={() => setCollapsed(!collapsed)}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h2>Pantry</h2>
        <button className="icon-btn" id="clear" aria-label="Clear pantry" onClick={onClear}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6" />
          </svg>
        </button>
        <div className="search">
          <input
            placeholder="Search ingredients"
            aria-label="Search ingredients"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <svg viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="7" />
            <path d="M20 20l-4-4" />
          </svg>
        </div>
      </div>

      <div className="side-body">
        <h3>Choose your Ingredients</h3>
        {categories.map(([name, items]) => (
          <div className="cat" key={name}>
            <h4>{name}</h4>
            <div className="chips">
              {items.map((item) => (
                <button
                  key={item}
                  className="chip"
                  aria-pressed={pantry.includes(item)}
                  onClick={() => onToggle(item)}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        ))}
        {status === 'loading' && <p className="empty">Loading ingredients…</p>}
        {status === 'error' && <p className="empty">Could not load ingredients from the database. {error}</p>}
        {status === 'ready' && !categories.length && <p className="empty">No ingredients match your search.</p>}
      </div>
    </aside>
  )
}
