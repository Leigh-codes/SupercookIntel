// Data access layer: the only file in the React app that talks to the backend.
// Components should call these functions instead of using fetch directly.

// Backend address. Override by creating a .env file in the project root with:
// VITE_API_URL=http://localhost:3001/api
const BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'

// The login token is kept in localStorage so the user stays logged in after a refresh
const getToken = () => localStorage.getItem('token')

// Shared helper: sends the request, attaches the token, and throws a readable error.
// The error carries `status` (the HTTP status; 0 when the server could not be reached).
async function request(path, options = {}) {
  let res
  try {
    res = await fetch(BASE + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(getToken() ? { Authorization: `Bearer ${getToken()}` } : {}),
        ...options.headers,
      },
    })
  } catch (err) {
    if (err.name === 'AbortError') throw err
    const e = new Error('Cannot reach the server. Start it with: npm run api')
    e.status = 0
    throw e
  }

  let data = null
  try {
    data = await res.json()
  } catch {
    // response had no JSON body
  }

  if (!res.ok) {
    const e = new Error((data && data.error) || 'Request failed')
    e.status = res.status
    throw e
  }
  return data
}

// ---------- Recipes and filter options ----------

// Returns [{ n, i, t, r, meal, cuisine, ... }, ...] (the shape the server's /recipes returns)
export const getRecipes = () => request('/recipes')

// Returns { meals, cuisines, ingredients: { Category: [names] }, aliases, ratings: [..], limits: { maxMinutes, maxIngredients } }
export const getMeta = () => request('/meta')

// ---------- Auth ----------

// Both return the username and remember the login token.
// login accepts the username or the email address.
export async function login(usernameOrEmail, password) {
  const data = await request('/login', {
    method: 'POST',
    body: JSON.stringify({ username: usernameOrEmail, password }),
  })
  localStorage.setItem('token', data.token)
  return data.username
}

export async function register(username, email, password) {
  const data = await request('/register', {
    method: 'POST',
    body: JSON.stringify({ username, email, password }),
  })
  localStorage.setItem('token', data.token)
  return data.username
}

export const logout = () => localStorage.removeItem('token')
export const hasToken = () => !!getToken()

// Is the saved login still valid? Resolves to { username, isAdmin }.
export const getMe = () => request('/me')

// ---------- Saved pantry and favorites (user must be logged in) ----------

// A list of ingredient names
export const getPantry = () => request('/pantry')
export const savePantry = (items) => request('/pantry', { method: 'PUT', body: JSON.stringify({ items }) })

// A list of recipe names, like the `fav` array in App.jsx
export const getFavorites = () => request('/favorites')

export const addFavorite = (name) =>
  request(`/favorites/${encodeURIComponent(name)}`, { method: 'POST' })

export const removeFavorite = (name) =>
  request(`/favorites/${encodeURIComponent(name)}`, { method: 'DELETE' })

// ---------- Search (database first, then the outside recipe service) ----------

// Returns [{ r: recipe, have: [matched ingredients] }, ...]
export function searchRecipes(pantry, filters, signal) {
  const params = new URLSearchParams({
    pantry: pantry.join(','),
    exclude: filters.exclude.join(','),
    meal: filters.meal.join(','),
    cuisine: filters.cuisine.join(','),
    maxIng: filters.maxIng,
    time: filters.time,
    rating: filters.rating,
  })
  return request(`/search?${params}`, { signal })
}
