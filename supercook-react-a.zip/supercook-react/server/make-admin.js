// Gives an account permission to add / edit / delete recipes:
//   node server/make-admin.js <username>
import { query, pool } from './db.js'

const username = process.argv[2]
if (!username) {
  console.error('Usage: node server/make-admin.js <username>')
  process.exit(1)
}

const result = await query('UPDATE users SET is_admin = 1 WHERE username = ?', [username])
console.log(result.affectedRows ? `"${username}" is now an admin.` : `No user named "${username}". Register that account first.`)
await pool.end()
