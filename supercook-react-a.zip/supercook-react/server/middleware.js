import jwt from 'jsonwebtoken'
import { query } from './db.js'

// Blocks requests that don't carry a valid login token. Sets req.user.
export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : ''
  let payload
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET)
  } catch {
    return res.status(401).json({ error: 'Please log in first' })
  }
  // Make sure the account still exists (it may have been deleted since the token was issued)
  const [user] = await query('SELECT user_id AS id, username, is_admin FROM users WHERE user_id = ?', [payload.id])
  if (!user) return res.status(401).json({ error: 'Please log in first' })
  req.user = user
  next()
}

// Only for admin accounts (used for adding / editing / deleting recipes)
export function requireAdmin(req, res, next) {
  if (!req.user?.is_admin) return res.status(403).json({ error: 'Admins only' })
  next()
}

// Very small in-memory limiter, used on login/register to slow down password guessing
export function rateLimit({ windowMs, max }) {
  const hits = new Map()
  setInterval(() => {
    const now = Date.now()
    for (const [key, rec] of hits) if (now > rec.reset) hits.delete(key)
  }, windowMs).unref()

  return (req, res, next) => {
    const now = Date.now()
    const rec = hits.get(req.ip)
    if (!rec || now > rec.reset) {
      hits.set(req.ip, { count: 1, reset: now + windowMs })
      return next()
    }
    if (++rec.count > max) {
      return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' })
    }
    next()
  }
}

// Last stop for any error, so the server answers with JSON instead of crashing
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err)
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' })
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That already exists' })
  if (['ECONNREFUSED', 'PROTOCOL_CONNECTION_LOST', 'ER_ACCESS_DENIED_ERROR', 'ER_BAD_DB_ERROR', 'ETIMEDOUT'].includes(err.code)) {
    console.error('Database problem:', err.code)
    return res.status(503).json({ error: 'The database is unavailable right now' })
  }
  console.error(err)
  res.status(500).json({ error: 'Something went wrong on the server' })
}
