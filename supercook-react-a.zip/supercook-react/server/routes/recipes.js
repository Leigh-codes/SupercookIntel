import { Router } from 'express'
import { requireAuth, requireAdmin } from '../middleware.js'
import { query } from '../db.js'
import { getAllRecipes, getRecipe, saveRecipe, getMeta } from '../recipeStore.js'

const router = Router()

// GET /api/recipes  ->  [{ id, n, i, opt, ing, t, r, meal, cuisine, s, e, url, img, ... }, ...]
router.get('/recipes', async (req, res) => {
  res.json(await getAllRecipes())
})

// GET /api/recipes/:id
router.get('/recipes/:id', async (req, res) => {
  const recipe = await getRecipe(Number(req.params.id))
  if (!recipe) return res.status(404).json({ error: 'Recipe not found' })
  res.json(recipe)
})

// GET /api/meta  ->  { meals, cuisines, ingredients: { Category: [names] }, aliases: { name: [aliases] } }
// Everything comes from the database: add a recipe with a new cuisine or meal type, or a new
// ingredient, and it shows up on the website by itself.
router.get('/meta', async (req, res) => {
  res.json(await getMeta())
})

// Checks a recipe sent by an admin. Returns { data } if fine, or { error }.
//   { name, meal, cuisine, ingredients: [{ name, quantity?, unit?, optional? } | "Name"],
//     time? (total minutes), servings?, image_url?, source_name?, source_url?, rating? }
function cleanRecipe(body = {}) {
  const text = (v) => String(v ?? '').trim()
  const num = (v, fallback) => (v === undefined || v === null || v === '' ? fallback : Number(v))

  const name = text(body.name)
  const meal = text(body.meal)
  const cuisine = text(body.cuisine)
  const time = num(body.time, 0) // recipe time = total minutes to make it
  const servings = num(body.servings, 1)
  const rating = body.rating === undefined || body.rating === null || body.rating === '' ? null : Number(body.rating)
  const image_url = text(body.image_url)
  const source_url = text(body.source_url)

  const ingredients = (Array.isArray(body.ingredients) ? body.ingredients : []).map((x) => {
    const o = typeof x === 'string' ? { name: x } : x || {}
    const quantity = o.quantity === undefined || o.quantity === null || o.quantity === '' ? null : Number(o.quantity)
    return { name: text(o.name), quantity, unit: text(o.unit).slice(0, 40) || null, optional: !!o.optional }
  })

  if (!name || name.length > 180) return { error: 'name is required (max 180 characters).' }
  if (!meal || meal.length > 60) return { error: 'meal is required (max 60 characters).' }
  if (!cuisine || cuisine.length > 100) return { error: 'cuisine is required (max 100 characters).' }
  if (!ingredients.length || ingredients.length > 60 || ingredients.some((x) => !x.name || x.name.length > 160)) {
    return { error: 'ingredients: send between 1 and 60 items, each with a name.' }
  }
  if (ingredients.some((x) => x.quantity !== null && (!Number.isFinite(x.quantity) || x.quantity < 0 || x.quantity > 99999999))) {
    return { error: 'ingredient quantity must be a positive number.' }
  }
  if (!ingredients.some((x) => !x.optional)) return { error: 'At least one ingredient must be required (not optional).' }
  for (const [label, v, max] of [['time', time, 1440], ['servings', servings, 1000]]) {
    if (!Number.isInteger(v) || v < 0 || v > max) return { error: `${label} must be a whole number from 0 to ${max}.` }
  }
  if (servings < 1) return { error: 'servings must be at least 1.' }
  if (rating !== null && (!Number.isInteger(rating) || rating < 1 || rating > 5)) return { error: 'rating must be a whole number from 1 to 5.' }
  if ((image_url && !/^https?:\/\/\S+$/i.test(image_url)) || (source_url && !/^https?:\/\/\S+$/i.test(source_url))) {
    return { error: 'Links must start with http:// or https://' }
  }

  return {
    data: {
      name, meal, cuisine, ingredients, time, servings, rating,
      image_url: image_url || null,
      source_url: source_url || null,
      source_name: text(body.source_name).slice(0, 120) || null,
    },
  }
}

async function save(req, res, id) {
  const { data, error } = cleanRecipe(req.body)
  if (error) return res.status(400).json({ error })
  try {
    const savedId = await saveRecipe(data, id)
    if (!savedId) return res.status(404).json({ error: 'Recipe not found' })
    res.status(id ? 200 : 201).json(await getRecipe(savedId))
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'A recipe with that name already exists.' })
    throw err
  }
}

// POST /api/recipes   (admin)
router.post('/recipes', requireAuth, requireAdmin, (req, res) => save(req, res, null))

// PUT /api/recipes/:id   (admin) replaces the whole recipe, so send every field
router.put('/recipes/:id', requireAuth, requireAdmin, (req, res) => save(req, res, Number(req.params.id)))

// DELETE /api/recipes/:id   (admin)
router.delete('/recipes/:id', requireAuth, requireAdmin, async (req, res) => {
  const result = await query('DELETE FROM recipes WHERE recipe_id = ?', [Number(req.params.id)])
  if (!result.affectedRows) return res.status(404).json({ error: 'Recipe not found' })
  res.json({ ok: true })
})

export default router
