import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { query } from '../db.js'
import { requireAuth, rateLimit } from '../middleware.js'

const router = Router()
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 })

const sign = (user) =>
  jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, { expiresIn: '7d' })

// Used so a wrong username takes as long to reject as a wrong password
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10)

// POST /api/register   { username, password, email? }  ->  { username, token }
router.post('/register', limiter, async (req, res) => {
  const username = String(req.body?.username ?? '').trim()
  const email = String(req.body?.email ?? '').trim().toLowerCase()
  const password = String(req.body?.password ?? '')

  if (username.length < 2 || username.length > 30) {
    return res.status(400).json({ error: 'Username must be 2 to 30 characters.' })
  }
  if (email && !/^\S+@\S+\.\S+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address.' })
  }
  if (password.length < 6 || password.length > 72) {
    return res.status(400).json({ error: 'Password must be 6 to 72 characters.' })
  }

  const taken = await query('SELECT username, email FROM users WHERE username = ? OR (email IS NOT NULL AND email = ?)', [
    username,
    email || null,
  ])
  if (taken.length) {
    const sameName = taken.some((u) => u.username.toLowerCase() === username.toLowerCase())
    return res.status(409).json({ error: sameName ? 'That username is taken.' : 'That email is already registered.' })
  }

  const hash = await bcrypt.hash(password, 10) // the plain password is never stored
  const result = await query('INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)', [
    username,
    email || null,
    hash,
  ])
  res.status(201).json({ username, token: sign({ id: result.insertId, username }) })
})

// POST /api/login   { username (or email), password }  ->  { username, token }
router.post('/login', limiter, async (req, res) => {
  const who = String(req.body?.username ?? req.body?.email ?? '').trim()
  const password = String(req.body?.password ?? '')

  const [user] = await query('SELECT user_id AS id, username, password_hash FROM users WHERE username = ? OR email = ?', [who, who])
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH)
  if (!user || !ok) return res.status(401).json({ error: 'Wrong username or password.' })

  res.json({ username: user.username, token: sign(user) })
})

// GET /api/me  ->  the logged-in user (handy for restoring a session after a refresh)
router.get('/me', requireAuth, (req, res) => {
  res.json({ username: req.user.username, isAdmin: !!req.user.is_admin })
})

export default router
