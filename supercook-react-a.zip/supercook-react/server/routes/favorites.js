import { Router } from 'express'
import { query } from '../db.js'
import { requireAuth } from '../middleware.js'

const router = Router()
router.use('/favorites', requireAuth) // every favorites route needs a login

// GET /api/favorites  ->  list of recipe names (same as the `fav` array in the website)
router.get('/favorites', async (req, res) => {
  const rows = await query(
    `SELECT r.recipe_name AS name FROM user_favorites f JOIN recipes r ON r.recipe_id = f.recipe_id
     WHERE f.user_id = ? ORDER BY f.created_at`,
    [req.user.id]
  )
  res.json(rows.map((r) => r.name))
})

// POST /api/favorites/:name   (404 for recipes that only come from the outside search: those stay in the browser)
router.post('/favorites/:name', async (req, res) => {
  const [recipe] = await query('SELECT recipe_id AS id FROM recipes WHERE recipe_name = ?', [req.params.name])
  if (!recipe) return res.status(404).json({ error: 'Recipe not found' })
  await query('INSERT IGNORE INTO user_favorites (user_id, recipe_id) VALUES (?, ?)', [req.user.id, recipe.id])
  res.json({ ok: true })
})

// DELETE /api/favorites/:name
router.delete('/favorites/:name', async (req, res) => {
  await query(
    `DELETE FROM user_favorites WHERE user_id = ?
     AND recipe_id = (SELECT recipe_id FROM recipes WHERE recipe_name = ?)`,
    [req.user.id, req.params.name]
  )
  res.json({ ok: true })
})

export default router
