// Database setup:   npm run db:setup      (safe to repeat; it never deletes your data)
//   1. creates the database named in .env (DB_NAME, default supercook_db) if it doesn't exist
//   2. loads database/supercook_db.sql, but ONLY when the database has no tables yet
//      (if you already imported it in phpMyAdmin, your data is left exactly as it is)
//   3. makes sure the account tables exist (users, user_pantry, user_favorites)
//   4. brings an older database up to date: recipe_minutes (replaces prep_minutes + cook_minutes),
//      source / link / rating columns on recipes, unique recipe names
import 'dotenv/config'
import fs from 'node:fs'
import mysql from 'mysql2/promise'

const DB = process.env.DB_NAME || 'supercook_db'
const read = (file) => fs.readFileSync(new URL(`../database/${file}`, import.meta.url), 'utf8')
// we create/select the database ourselves (from DB_NAME), so drop those lines from the .sql files
const withoutDbLines = (sql) => sql.replace(/^\s*(CREATE DATABASE|USE)\b.*$/gim, '')

const conn = await mysql
  .createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    charset: 'utf8mb4',
    multipleStatements: true,
  })
  .catch((err) => {
    console.error(`Could not connect to MySQL (${err.code || err.message}).`)
    console.error('Start MySQL (XAMPP / Laragon "Start") and check DB_HOST / DB_PORT / DB_USER / DB_PASSWORD in .env.')
    process.exit(1)
  })

const columnsOf = async (table) => {
  const [rows] = await conn.query(
    'SELECT COLUMN_NAME AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
    [DB, table]
  )
  return new Set(rows.map((r) => r.c))
}

try {
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`)
  await conn.query(`USE \`${DB}\``)

  // Is the data already there (imported in phpMyAdmin, or by an earlier run)?
  const [[{ existing }]] = await conn.query(
    "SELECT COUNT(*) AS existing FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ('ingredients', 'recipes')",
    [DB]
  )
  const alreadyThere = () => console.log(`Database "${DB}": tables already exist, so supercook_db.sql was not loaded (your data is untouched)`)
  if (Number(existing) > 0) {
    alreadyThere()
  } else {
    try {
      await conn.query(withoutDbLines(read('supercook_db.sql')))
      console.log(`Database "${DB}": supercook_db.sql loaded`)
    } catch (err) {
      if (err.code !== 'ER_TABLE_EXISTS_ERROR') throw err
      alreadyThere() // a partly imported database: keep what is there
    }
  }

  await conn.query(withoutDbLines(read('app_tables.sql')))

  // ---- bring an older recipes table up to date ----
  let columns = await columnsOf('recipes')

  if (!columns.has('recipe_minutes')) {
    await conn.query("ALTER TABLE recipes ADD COLUMN recipe_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'total minutes to make the recipe' AFTER cuisine_type")
    if (columns.has('prep_minutes') && columns.has('cook_minutes')) {
      await conn.query('UPDATE recipes SET recipe_minutes = prep_minutes + cook_minutes') // old times added together
    }
    await conn.query('ALTER TABLE recipes ADD KEY idx_recipes_recipe_minutes (recipe_minutes)')
    console.log('  added recipes.recipe_minutes (prep + cook added together)')
    columns = await columnsOf('recipes')
  }
  // only after recipe_minutes exists and is filled in
  for (const old of ['prep_minutes', 'cook_minutes']) {
    if (columns.has(old)) {
      await conn.query(`ALTER TABLE recipes DROP COLUMN \`${old}\``)
      console.log(`  removed recipes.${old}`)
    }
  }

  const add = {
    source_name: 'VARCHAR(120) NULL', // site shown on the card, e.g. goodfood.com
    source_url: 'VARCHAR(500) NULL', // link to the original page
    rating: 'TINYINT UNSIGNED NULL', // 1 to 5, NULL = not rated yet
  }
  for (const [name, type] of Object.entries(add)) {
    if (!columns.has(name)) {
      await conn.query(`ALTER TABLE recipes ADD COLUMN \`${name}\` ${type}`)
      console.log(`  added recipes.${name}`)
    }
  }

  // Recipe names identify favorites in the website, so they must be unique
  const [idx] = await conn.query(
    "SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'recipes' AND COLUMN_NAME = 'recipe_name' AND NON_UNIQUE = 0",
    [DB]
  )
  if (!idx.length) {
    try {
      await conn.query('ALTER TABLE recipes ADD UNIQUE KEY uq_recipes_name (recipe_name)')
      console.log('  recipe names are now unique')
    } catch (err) {
      console.warn(`  could not make recipe names unique (${err.code}). You have two recipes with the same name: rename one.`)
    }
  }

  const [[c]] = await conn.query(
    `SELECT (SELECT COUNT(*) FROM ingredients) AS ingredients,
            (SELECT COUNT(*) FROM ingredient_aliases) AS aliases,
            (SELECT COUNT(*) FROM recipes) AS recipes,
            (SELECT COUNT(*) FROM recipe_ingredients) AS links`
  )
  console.log(`\nReady: ${c.recipes} recipes, ${c.ingredients} ingredients, ${c.aliases} aliases, ${c.links} recipe-ingredient links.`)
  console.log('Next:  npm run api   (then in a second window: npm run dev)')
} catch (err) {
  console.error(`\nSetup failed: ${err.code || ''} ${err.sqlMessage || err.message}`)
  process.exitCode = 1
} finally {
  await conn.end()
}
