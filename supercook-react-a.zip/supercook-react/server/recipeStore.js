import { query, transaction } from './db.js'

// Every recipe leaves the database in the shape the website uses (the website reads this shape):
//   n = name, i = REQUIRED ingredient names, t = total minutes, r = stars (0 = not rated),
//   s = source site, e = emoji, meal, cuisine, img, url
// plus extras for the recipe pop-up:
//   opt = optional ingredient names, ing = [{ name, quantity, unit, optional }],
//   steps (only outside recipes have instructions), servings, id
const EMOJI = { Breakfast: '🍳', Lunch: '🥗', Dinner: '🍽️', Snack: '🍿', Dessert: '🍰' }

const RECIPE_SQL = `
  SELECT recipe_id, recipe_name, meal_type, cuisine_type, recipe_minutes,
         servings, image_url, source_name, source_url, rating
  FROM recipes`

const LINES_SQL = `
  SELECT ri.recipe_id, i.ingredient_name AS name, ri.quantity, ri.unit, ri.is_optional
  FROM recipe_ingredients ri
  JOIN ingredients i ON i.ingredient_id = ri.ingredient_id`

function shape(row, lines = []) {
  const ing = lines.map((l) => ({
    name: l.name,
    quantity: l.quantity === null || l.quantity === undefined ? null : Number(l.quantity),
    unit: l.unit || '',
    optional: !!l.is_optional,
  }))
  const meal = row.meal_type || 'Other'
  return {
    id: row.recipe_id,
    n: row.recipe_name,
    e: EMOJI[meal] || '🍽️',
    s: row.source_name || '',
    url: row.source_url || '',
    img: row.image_url || '',
    meal,
    cuisine: row.cuisine_type || 'Other',
    t: Number(row.recipe_minutes), // recipe time: total minutes to make it
    r: Number(row.rating) || 0,
    i: ing.filter((x) => !x.optional).map((x) => x.name),
    opt: ing.filter((x) => x.optional).map((x) => x.name),
    ing,
    steps: '', // the database has no instructions; outside recipes bring their own
    servings: Number(row.servings) || 1,
  }
}

function group(lines) {
  const byRecipe = new Map()
  for (const l of lines) {
    if (!byRecipe.has(l.recipe_id)) byRecipe.set(l.recipe_id, [])
    byRecipe.get(l.recipe_id).push(l)
  }
  return byRecipe
}

export async function getAllRecipes() {
  const [rows, lines] = await Promise.all([
    query(`${RECIPE_SQL} ORDER BY recipe_name`),
    query(`${LINES_SQL} ORDER BY ri.is_optional, i.ingredient_name`),
  ])
  const byRecipe = group(lines)
  return rows.map((r) => shape(r, byRecipe.get(r.recipe_id)))
}

export async function getRecipe(id) {
  const [row] = await query(`${RECIPE_SQL} WHERE recipe_id = ?`, [id])
  if (!row) return null
  const lines = await query(`${LINES_SQL} WHERE ri.recipe_id = ? ORDER BY ri.is_optional, i.ingredient_name`, [id])
  return shape(row, lines)
}

// ---------- ingredients ----------

// Where a brand-new ingredient name (typed by an admin) is filed until someone sorts it
const FALLBACK_SUBCATEGORY = 'Other specialty ingredients'

// Make sure every ingredient exists (matching is case-insensitive, and aliases count);
// returns ids in the same order as `names`. q is the query function from transaction().
export async function ensureIngredients(q, names) {
  const ids = []
  for (const raw of names) {
    const name = String(raw).trim()
    const [found] = await q(
      `SELECT ingredient_id AS id FROM ingredients WHERE ingredient_name = ?
       UNION
       SELECT ingredient_id FROM ingredient_aliases WHERE alias_name = ? LIMIT 1`,
      [name, name]
    )
    if (found) {
      ids.push(found.id)
      continue
    }
    const [sub] = await q('SELECT subcategory_id AS id FROM ingredient_subcategories WHERE subcategory_name = ?', [FALLBACK_SUBCATEGORY])
    if (!sub) throw new Error(`Subcategory "${FALLBACK_SUBCATEGORY}" is missing: run npm run db:setup`)
    const res = await q('INSERT INTO ingredients (subcategory_id, ingredient_name) VALUES (?, ?)', [sub.id, name])
    ids.push(res.insertId)
  }
  return ids
}

// Create (id = null) or update a recipe together with its ingredient lines.
// data.ingredients = [{ name, quantity, unit, optional }]. Returns the recipe id, or null if id doesn't exist.
export async function saveRecipe(data, id = null) {
  return transaction(async (q) => {
    const values = [
      data.meal, data.cuisine, data.time, data.servings,
      data.image_url, data.source_name, data.source_url, data.rating,
    ]
    let recipeId = id

    if (id) {
      const [exists] = await q('SELECT recipe_id FROM recipes WHERE recipe_id = ?', [id])
      if (!exists) return null
      await q(
        `UPDATE recipes SET recipe_name = ?, meal_type = ?, cuisine_type = ?, recipe_minutes = ?,
                servings = ?, image_url = ?, source_name = ?, source_url = ?, rating = ?
         WHERE recipe_id = ?`,
        [data.name, ...values, id]
      )
      await q('DELETE FROM recipe_ingredients WHERE recipe_id = ?', [id])
    } else {
      const result = await q(
        `INSERT INTO recipes (recipe_name, meal_type, cuisine_type, recipe_minutes, servings,
                              image_url, source_name, source_url, rating)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [data.name, ...values]
      )
      recipeId = result.insertId
    }

    const ids = await ensureIngredients(q, data.ingredients.map((x) => x.name))
    const seen = new Set()
    const rows = []
    data.ingredients.forEach((x, k) => {
      if (seen.has(ids[k])) return // same ingredient listed twice: keep the first
      seen.add(ids[k])
      rows.push([recipeId, ids[k], x.quantity, x.unit, x.optional ? 1 : 0])
    })
    await q('INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, is_optional) VALUES ?', [rows])
    return recipeId
  })
}

// ---------- catalog for the website's filters and pantry ----------

export async function getMeta() {
  const mealRows = await query("SELECT DISTINCT meal_type AS v FROM recipes WHERE meal_type IS NOT NULL AND meal_type <> ''")
  const cuisineRows = await query("SELECT DISTINCT cuisine_type AS v FROM recipes WHERE cuisine_type IS NOT NULL AND cuisine_type <> ''")

  // the usual meals first, in the usual order; anything new after them, A-Z
  const usual = ['Breakfast', 'Lunch', 'Dinner', 'Snack', 'Dessert']
  const rank = (m) => (usual.includes(m) ? usual.indexOf(m) : usual.length)
  const meals = mealRows.map((m) => m.v).sort((a, b) => rank(a) - rank(b) || a.localeCompare(b))
  const cuisines = cuisineRows.map((c) => c.v).sort((a, b) => a.localeCompare(b))
  const rows = await query(
    `SELECT c.category_name AS category, i.ingredient_name AS name
     FROM ingredients i
     JOIN ingredient_subcategories s ON s.subcategory_id = i.subcategory_id
     JOIN ingredient_categories c ON c.category_id = s.category_id
     ORDER BY c.category_id, s.subcategory_id, i.ingredient_name`
  )
  const aliasRows = await query(
    `SELECT i.ingredient_name AS name, a.alias_name AS alias
     FROM ingredient_aliases a JOIN ingredients i ON i.ingredient_id = a.ingredient_id`
  )

  const ingredients = {}
  for (const { category, name } of rows) (ingredients[category] ||= []).push(name)
  const aliases = {}
  for (const { name, alias } of aliasRows) (aliases[name] ||= []).push(alias)

  const [{ maxMinutes }] = await query('SELECT COALESCE(MAX(recipe_minutes), 0) AS maxMinutes FROM recipes')
  const [{ maxIngredients }] = await query(
    `SELECT COALESCE(MAX(n), 0) AS maxIngredients
     FROM (SELECT COUNT(*) AS n FROM recipe_ingredients WHERE is_optional = 0 GROUP BY recipe_id) AS counts`
  )
  const ratingRows = await query('SELECT DISTINCT rating AS v FROM recipes WHERE rating IS NOT NULL ORDER BY rating')

  return {
    meals,
    cuisines,
    ingredients,
    aliases,
    ratings: ratingRows.map((r) => Number(r.v)),
    limits: { maxMinutes: Number(maxMinutes), maxIngredients: Number(maxIngredients) },
  }
}

// "scallion" -> "Spring onions". Anything unknown is returned unchanged.
export async function canonicalIngredients(names) {
  const clean = [...new Set(names.map((n) => String(n).trim()).filter(Boolean))]
  if (!clean.length) return []
  const official = await query('SELECT ingredient_name AS name FROM ingredients WHERE ingredient_name IN (?)', [clean])
  const viaAlias = await query(
    `SELECT a.alias_name AS typed, i.ingredient_name AS name
     FROM ingredient_aliases a JOIN ingredients i ON i.ingredient_id = a.ingredient_id
     WHERE a.alias_name IN (?)`,
    [clean]
  )
  const canon = new Map() // lowercase typed name -> official name (matching is case-insensitive)
  for (const { typed, name } of viaAlias) canon.set(typed.toLowerCase(), name)
  for (const { name } of official) canon.set(name.toLowerCase(), name)
  return [...new Set(clean.map((n) => canon.get(n.toLowerCase()) || n))]
}
