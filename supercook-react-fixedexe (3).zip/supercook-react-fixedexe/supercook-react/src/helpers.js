// React state must not be changed in place, so this returns a NEW array:
// remove the value if it is there, add it if it is not.
export function toggle(list, value) {
  return list.includes(value) ? list.filter((x) => x !== value) : [...list, value]
}

// Everything in a, then whatever in b is not already there
export const union = (a, b) => [...a, ...b.filter((x) => !a.includes(x))]

// Recipe instructions come as one text: "1. Mix. 2. Cook." (our database) or one step per line
// (outside recipes). Returns a list of steps.
export function parseSteps(text) {
  const t = String(text || '').trim()
  if (!t) return []
  const numbered = t.split(/(?:^|\s)\d{1,2}\.\s+/).map((s) => s.trim()).filter(Boolean)
  if (numbered.length > 1) return numbered
  return t.split(/\n+/).map((s) => s.trim()).filter(Boolean)
}

// One ingredient line for the recipe pop-up: "0.5 cup Soy sauce"
export function ingredientLine({ name, quantity, unit }) {
  const q = quantity === null || quantity === undefined ? '' : String(+Number(quantity).toFixed(2))
  return [q, unit, name].filter(Boolean).join(' ')
}
