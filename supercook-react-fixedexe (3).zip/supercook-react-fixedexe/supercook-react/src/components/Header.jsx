import Filters from './Filters.jsx'

// The red top bar: login/user area, title and the filter pills
export default function Header({ user, onLogin, onLogout, filters, setFilters }) {
  return (
    <header>
      <div className="user">
        {user ? (
          <>
            <div className="avatar">{user[0].toUpperCase()}</div>
            <div>
              <b>{user}</b>
              <button onClick={onLogout}>Log out</button>
            </div>
          </>
        ) : (
          <button className="pill" onClick={onLogin}>
            Log in
          </button>
        )}
      </div>
      <h1>SuperCook</h1>
      <p>Fetching recipes suited to your available ingredients</p>
      <Filters filters={filters} setFilters={setFilters} />
    </header>
  )
}
