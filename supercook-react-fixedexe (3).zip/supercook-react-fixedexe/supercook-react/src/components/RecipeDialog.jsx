import { useRef, useEffect } from 'react'
import DishImage from './DishImage.jsx'
import { parseSteps, ingredientLine } from '../helpers.js'

// The pop-up with recipe details. Uses the browser's built-in <dialog>.
export default function RecipeDialog({ recipe, pantry, isFav, onToggleFav, onClose }) {
  const ref = useRef(null)

  // Open or close the <dialog> whenever `recipe` changes
  useEffect(() => {
    const d = ref.current
    if (recipe && !d.open) d.showModal()
    if (!recipe && d.open) d.close()
  }, [recipe])

  // Lines with quantities (database / outside recipes)
  const lines = recipe ? (recipe.ing?.length ? recipe.ing : recipe.i.map((name) => ({ name }))) : []
  const steps = recipe ? parseSteps(recipe.steps) : []
  const facts = recipe
    ? [recipe.s, recipe.meal, recipe.cuisine, recipe.t ? `Recipe time: ${recipe.t} min` : '', recipe.r ? `★ ${+Number(recipe.r).toFixed(1)}` : '']
        .filter(Boolean)
        .join(' · ')
    : ''

  return (
    <dialog
      ref={ref}
      className="info"
      onClose={onClose}
      onClick={(e) => e.target === ref.current && onClose()} // click on the dark backdrop
    >
      {recipe && (
        <div className="info">
          <div className="top">
            <DishImage recipe={recipe} />
          </div>
          <div className="in">
            <h2>{recipe.n}</h2>
            <small>{facts}</small>

            <h3>Ingredients{recipe.servings ? ` · serves ${recipe.servings}` : ''}</h3>
            <ul>
              {lines.map((line) => {
                const have = pantry.includes(line.name)
                return (
                  <li key={line.name} className={(have ? 'have ' : '') + (line.optional ? 'opt' : '')}>
                    {ingredientLine(line) + (line.optional ? ' (optional)' : '') + (have ? ' (in pantry)' : '')}
                  </li>
                )
              })}
            </ul>

            {steps.length > 0 && (
              <>
                <h3>Instructions</h3>
                <ol>
                  {steps.map((step, k) => (
                    <li key={k}>{step}</li>
                  ))}
                </ol>
              </>
            )}

            <div className="row">
              <button className="btn" onClick={() => onToggleFav(recipe)}>
                {isFav ? 'Remove favorite' : 'Save to favorites'}
              </button>
              {recipe.url && (
                <a className="btn alt" href={recipe.url} target="_blank" rel="noopener noreferrer">
                  View on {recipe.s || 'original site'}
                </a>
              )}
              <button className="btn alt" onClick={onClose}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </dialog>
  )
}
