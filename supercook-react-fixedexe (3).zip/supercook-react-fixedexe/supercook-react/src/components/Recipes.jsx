import RecipeCard from './RecipeCard.jsx'

// The main area: a message, or the grid of matching recipes
export default function Recipes({ results, hasPantry, favOnly, fav, onToggleFav, onOpen }) {
  if (!hasPantry && !favOnly) {
    return <div className="start">Add your ingredients to get started</div>
  }

  if (!results.length) {
    return (
      <div className="start">
        {favOnly
          ? 'No favorites yet. Tap a heart on any recipe.'
          : 'No recipes match. Try adding ingredients or loosening filters.'}
      </div>
    )
  }

  return (
    <>
      <div className="count">
        You can make {results.length} recipe{results.length > 1 ? 's' : ''}
      </div>
      <div className="grid">
        {results.map(({ r, have }) => (
          <RecipeCard
            key={r.n}
            recipe={r}
            have={have}
            isFav={fav.includes(r.n)}
            onToggleFav={onToggleFav}
            onOpen={onOpen}
          />
        ))}
      </div>
    </>
  )
}
