import { useState, useEffect, useMemo } from 'react'
import { useCatalog } from '../catalog.jsx'
import { toggle } from '../helpers.js'

// A row of clickable chips where several can be selected
function ChipGroup({ options, selected, onToggle }) {
  return (
    <div className="chips">
      {options.map((o) => (
        <button key={o} className="chip" aria-pressed={selected.includes(o)} onClick={() => onToggle(o)}>
          {o}
        </button>
      ))}
    </div>
  )
}

// A slider with a text label above it
function Range({ label, text, min, max, step, value, onChange }) {
  return (
    <div>
      <label>{text}</label>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        aria-label={label}
        onChange={(e) => onChange(+e.target.value)}
      />
    </div>
  )
}

// Exclude filter: a search box on top, then the matching ingredient chips
function ExcludePicker({ selected, onToggle }) {
  const { ingredients } = useCatalog()
  const [search, setSearch] = useState('')

  // Every known ingredient, A-Z, for the Exclude list
  const all = useMemo(() => Object.values(ingredients).flat().sort(), [ingredients])
  const matches = all.filter((o) => o.toLowerCase().includes(search.trim().toLowerCase()))

  return (
    <div>
      <input
        type="text"
        className="search-input"
        placeholder="Search ingredients..."
        aria-label="Search ingredients to exclude"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        autoFocus
      />
      <div className="exclude-list">
        {matches.length ? (
          <ChipGroup options={matches} selected={selected} onToggle={onToggle} />
        ) : (
          <p className="no-match">No ingredients found</p>
        )}
      </div>
    </div>
  )
}

// Rating filter: "Any" plus one button for each rating that exists in the database
function RatingButtons({ value, onChange, ratings }) {
  if (!ratings.length) return <p className="no-match">No recipes have a rating yet.</p>
  return (
    <div className="chips">
      {[[0, 'Any'], ...ratings.map((v) => [v, `${v}★ & up`])].map(([v, text]) => (
        <button key={v} className="chip" aria-pressed={value === v} onClick={() => onChange(v)}>
          {text}
        </button>
      ))}
    </div>
  )
}

// "75" -> "1 h 15 min"
const duration = (m) => (m >= 60 ? `${Math.floor(m / 60)} h${m % 60 ? ` ${m % 60} min` : ''}` : `${m} min`)

export default function Filters({ filters, setFilters }) {
  const { meals, cuisines, ratings, limits } = useCatalog()
  const maxTime = Math.ceil(limits.maxMinutes / 5) * 5 // slider top = the longest recipe in the database
  // Which popup is open right now (null = none)
  const [openKey, setOpenKey] = useState(null)

  // Update one filter field without touching the others
  const set = (key, value) => setFilters({ ...filters, [key]: value })

  // Click anywhere else, or press Escape, to close the popup
  useEffect(() => {
    const close = () => setOpenKey(null)
    const onKey = (e) => e.key === 'Escape' && close()
    document.addEventListener('click', close)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('click', close)
      document.removeEventListener('keydown', onKey)
    }
  }, [])

  const pills = [
    ['exclude', 'Exclude'],
    ['meal', 'Meal Type'],
    ['cuisine', 'Cuisines'],
    ['maxIng', 'Max Ingredients'],
    ['time', 'Recipe Time'],
    ['fav', 'My Favorites'],
    ['rating', 'Rating'],
  ]

  function renderPopup(key, label) {
    if (key === 'exclude')
      return <ExcludePicker selected={filters.exclude} onToggle={(o) => set('exclude', toggle(filters.exclude, o))} />
    if (key === 'meal')
      return meals.length ? (
        <ChipGroup options={meals} selected={filters.meal} onToggle={(o) => set('meal', toggle(filters.meal, o))} />
      ) : (
        <p className="no-match">No meal types in the database.</p>
      )
    if (key === 'cuisine')
      return cuisines.length ? (
        <ChipGroup options={cuisines} selected={filters.cuisine} onToggle={(o) => set('cuisine', toggle(filters.cuisine, o))} />
      ) : (
        <p className="no-match">No cuisines in the database.</p>
      )
        if (key === 'maxIng') {
      const max = limits.maxIngredients
      if (max < 2) return <p className="no-match">Not enough recipes yet.</p>
      const value = Math.min(filters.maxIng, max)
      return (
        <Range
          label={label}
          text={`Up to ${value} ingredient${value === 1 ? '' : 's'}`}
          min={1}
          max={max}
          step={1}
          value={value}
          onChange={(v) => set('maxIng', v)}
        />
      )
    }
    
    if (key === 'time') {
      const value = Math.min(Math.max(0, filters.time), maxTime)
      const hours = Math.floor(value / 60)
      const minutes = value % 60

      return (
        <div>
          <div className="recipe-time-inputs">
            <label>
              Hours
              <input
                type="number"
                min="0"
                max={Math.floor(maxTime / 60)}
                step="1"
                value={hours}
                onChange={(e) => {
                  const h = Math.max(0, Math.floor(Number(e.target.value) || 0))
                  set('time', Math.min(h * 60 + minutes, maxTime))
                }}
              />
            </label>

            <label>
              Minutes
              <input
                type="number"
                min="0"
                max="59"
                step="1"
                value={minutes}
                onChange={(e) => {
                  const m = Math.min(59, Math.max(0, Math.floor(Number(e.target.value) || 0)))
                  set('time', Math.min(hours * 60 + m, maxTime))
                }}
              />
            </label>
          </div>
        </div>
      )
    }
    if (key === 'rating')
      return <RatingButtons value={filters.rating} ratings={ratings} onChange={(v) => set('rating', v)} />
  }

  return (
    <div className="filters">
      {pills.map(([key, label]) => {
        // "My Favorites" is a simple on/off button, no popup
        if (key === 'fav') {
          return (
            <div className="pillwrap" key={key}>
              <button
                className={'pill' + (filters.favOnly ? ' on' : '')}
                aria-pressed={filters.favOnly}
                onClick={() => set('favOnly', !filters.favOnly)}
              >
                {label}
              </button>
            </div>
          )
        }

        const isOpen = openKey === key
        return (
          <div className="pillwrap" key={key}>
            <button
              className="pill"
              aria-expanded={isOpen}
              aria-haspopup="true"
              onClick={(e) => {
                e.stopPropagation() // stops the "click anywhere to close" above from firing
                setOpenKey(isOpen ? null : key)
              }}
            >
              {label}
            </button>
            {isOpen && (
              <div className="pop" role="group" aria-label={label} onClick={(e) => e.stopPropagation()}>
                {renderPopup(key, label)}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}