import { useState, useEffect } from 'react'

// The photo of a dish. Shows the emoji instead when there is no photo or the picture cannot be loaded
// (for example the API is off, or the image link in the database is broken).
export default function DishImage({ recipe, lazy = false }) {
  const [broken, setBroken] = useState(false)
  useEffect(() => setBroken(false), [recipe.img])

  if (!recipe.img || broken) return recipe.e
  return <img className="thumb" src={recipe.img} alt={recipe.n} loading={lazy ? 'lazy' : undefined} onError={() => setBroken(true)} />
}
