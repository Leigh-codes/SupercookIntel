import { useState } from 'react'
import { useCatalog } from '../catalog.jsx'

// The green sidebar: search box + ingredient buttons grouped by category.
// The list button (top left) switches between two views:
//   - all ingredients, so you can pick more
//   - "My Pantry": only the ingredients you picked, each under its category
// In both views the ingredients are buttons, so a click on a picked one removes it.
export default function Pantry({ pantry, onToggle, onClear }) {
  const { ingredients, aliases, status, error } = useCatalog()
  const [query, setQuery] = useState('')
  const [showPicked, setShowPicked] = useState(false)

  const q = query.trim().toLowerCase()
  // Does an ingredient match the search? Alternate names (aliases) count too.
  const matches = (item) => !q || item.toLowerCase().includes(q) || (aliases[item] || []).some((a) => a.toLowerCase().includes(q))

  // [[category name, [ingredient names]], ...] for whichever view is showing
  let groups
  if (showPicked) {
    const picked = new Set(pantry)
    groups = Object.entries(ingredients).map(([name, items]) => [name, items.filter((i) => picked.has(i))])
    // A picked ingredient the database no longer lists still shows, so it can be removed
    const known = new Set(groups.flatMap(([, items]) => items))
    const unlisted = pantry.filter((i) => !known.has(i))
    if (unlisted.length) groups.push(['Other', unlisted])
  } else {
    groups = Object.entries(ingredients)
  }
  // Apply the search, and drop categories that end up empty
  groups = groups.map(([name, items]) => [name, items.filter(matches)]).filter(([, items]) => items.length)

  function toggleView() {
    setShowPicked(!showPicked)
    setQuery('') // a leftover search would hide things in the other view
  }

  return (
    <aside>
      <div className="side-top">
        <button
          className="icon-btn"
          id="toggle"
          aria-label={showPicked ? 'Show all ingredients' : 'Show only my picked ingredients'}
          aria-pressed={showPicked}
          title={showPicked ? 'Show all ingredients' : 'Show only my picked ingredients'}
          onClick={toggleView}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h2>{showPicked ? 'My Pantry' : 'Pantry'}</h2>
        <button className="icon-btn" id="clear" aria-label="Clear pantry" onClick={onClear}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14M10 11v6M14 11v6" />
          </svg>
        </button>
        <div className="search">
          <input
            placeholder={showPicked ? 'Search my ingredients' : 'Search ingredients'}
            aria-label={showPicked ? 'Search my picked ingredients' : 'Search ingredients'}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <svg viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2.5" strokeLinecap="round">
            <circle cx="11" cy="11" r="7" />
            <path d="M20 20l-4-4" />
          </svg>
        </div>
      </div>

      <div className="side-body">
        {!showPicked && <h3>Choose your Ingredients</h3>}
        {groups.map(([name, items]) => (
          <div className="cat" key={name}>
            <h4>{name}</h4>
            <div className="chips">
              {items.map((item) => (
                <button key={item} className="chip" aria-pressed={pantry.includes(item)} onClick={() => onToggle(item)}>
                  {item}
                </button>
              ))}
            </div>
          </div>
        ))}
        {status === 'loading' && <p className="empty">Loading ingredients…</p>}
        {status === 'error' && <p className="empty">Could not load ingredients from the database. {error}</p>}
        {status !== 'loading' && !groups.length && (
          <p className="empty">
            {!showPicked
              ? 'No ingredients match your search.'
              : pantry.length
                ? 'None of your picked ingredients match your search.'
                : 'You have not picked any ingredients yet. Tap the list button to go back and choose some.'}
          </p>
        )}
      </div>
    </aside>
  )
}
