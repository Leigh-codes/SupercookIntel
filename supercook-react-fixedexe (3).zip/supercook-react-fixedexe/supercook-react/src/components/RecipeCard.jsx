import DishImage from './DishImage.jsx'

function HeartIcon() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2" strokeLinejoin="round">
      <path d="M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.800-8 11-8 11z" />
    </svg>
  )
}

export default function RecipeCard({ recipe, have, isFav, onToggleFav, onOpen }) {
  return (
    <div className="card">
      <div className="img">
        <DishImage recipe={recipe} lazy />
        <button
          className="heart"
          aria-pressed={isFav}
          aria-label={(isFav ? 'Remove ' : 'Add ') + recipe.n + (isFav ? ' from' : ' to') + ' favorites'}
          onClick={() => onToggleFav(recipe)}
        >
          <HeartIcon />
        </button>
      </div>
      <button className="body" onClick={() => onOpen(recipe)}>
        <b>{recipe.n}</b>
        <small>{recipe.s}</small>
        <div className="m">
          {have.length} ingredient{have.length === 1 ? '' : 's'} matched
        </div>
      </button>
    </div>
  )
}
