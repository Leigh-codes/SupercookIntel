import { useState, useEffect, useRef } from 'react'
import { toggle, union } from './helpers.js'
import { matchRecipes } from './matching.js'
import { searchRecipes, getMe, getPantry, savePantry, getFavorites, addFavorite, removeFavorite, logout, hasToken } from './api.js'
import { useCatalog } from './catalog.jsx'
import useLocalStorage from './useLocalStorage.js'
import Pantry from './components/Pantry.jsx'
import Header from './components/Header.jsx'
import Recipes from './components/Recipes.jsx'
import AuthForm from './components/AuthForm.jsx'
import RecipeDialog from './components/RecipeDialog.jsx'

const defaultFilters = {
  exclude: [],
  meal: [],
  cuisine: [],
  maxIng: 99,
  time: 1440, // 1440 = no time limit
  rating: 0,
  favOnly: false,
}

export default function App() {
  const { recipes } = useCatalog() // recipes from the database

  // Saved in the browser (and copied to your account while you are logged in)
  const [pantry, setPantry] = useLocalStorage('pantry', [])
  const [fav, setFav] = useLocalStorage('fav', [])
  const [favExt, setFavExt] = useLocalStorage('favExt', {}) // favorited outside recipes, kept whole: they are not in our database
  const [user, setUser] = useLocalStorage('user', null)

  // Only for this visit
  const [view, setView] = useState('recipes') // 'recipes' | 'login' | 'register'
  const [filters, setFilters] = useState(defaultFilters)
  const [selected, setSelected] = useState(null) // recipe shown in the dialog
  const [found, setFound] = useState([]) // search results from the API
  const [synced, setSynced] = useState(false) // true once the account's saved pantry/favorites were loaded

  // ---------- account sync ----------

  // Bring the account's saved pantry and favorites into this browser (merged with what is here).
  // Changes are only sent up AFTER this ran, so a fresh browser can never wipe the saved data.
  async function pullAccount() {
    try {
      const [serverPantry, serverFav] = await Promise.all([getPantry(), getFavorites()])
      setPantry((p) => union(p, serverPantry))
      setFav((f) => union(f, serverFav))
      setSynced(true)
    } catch (err) {
      if (err.status === 401) endSession() // the login expired
    }
  }

  function endSession() {
    logout()
    setUser(null)
    setSynced(false)
  }

  // On page load: is the saved login still good?
  const checked = useRef(false)
  useEffect(() => {
    if (checked.current) return // StrictMode runs effects twice in development
    checked.current = true
    if (!user) return
    if (!hasToken()) return setUser(null)
    getMe()
      .then(pullAccount)
      .catch((err) => err.status === 401 && endSession()) // API unreachable: stay logged in, retry next visit
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Save the pantry to the account shortly after it changes
  useEffect(() => {
    if (!user || !synced) return
    const timer = setTimeout(() => savePantry(pantry).catch(() => {}), 600)
    return () => clearTimeout(timer)
  }, [pantry, user, synced])

  // ---------- search ----------

  // Ask the search API whenever the pantry or filters change. The API looks in the
  // database first and tops up from the outside recipe service when needed.
  // The short wait avoids a request on every click; the abort drops stale requests.
  useEffect(() => {
    if (!pantry.length) {
      setFound([])
      return
    }
    const controller = new AbortController()
    const timer = setTimeout(async () => {
      try {
        setFound(await searchRecipes(pantry, filters, controller.signal))
      } catch (err) {
        if (err.name === 'AbortError') return
        setFound(matchRecipes(recipes, pantry, filters)) // search API unreachable: match in the browser
      }
    }, 400)
    return () => {
      clearTimeout(timer)
      controller.abort()
    }
  }, [pantry, filters, recipes])

  // "My Favorites" shows every saved recipe that passes the filters (a pantry is not needed)
  const results = filters.favOnly
    ? matchRecipes(
        [...recipes, ...Object.values(favExt)].filter((r) => fav.includes(r.n)),
        pantry,
        filters,
        { requirePantry: false }
      )
    : found

  function toggleFav(recipe) {
    const adding = !fav.includes(recipe.n)
    setFav(toggle(fav, recipe.n))
    if (recipe.ext) {
      setFavExt((m) => {
        const next = { ...m }
        if (adding) next[recipe.n] = recipe
        else delete next[recipe.n]
        return next
      })
    }
    if (user && synced && !recipe.ext) (adding ? addFavorite : removeFavorite)(recipe.n).catch(() => {})
  }

  function handleAuth(username) {
    setUser(username)
    setView('recipes')
    pullAccount()
  }

  function handleLogout() {
    endSession()
    setView('recipes')
  }

  return (
    <>
      <div className="app">
        <Pantry
          pantry={pantry}
          onToggle={(ingredient) => setPantry(toggle(pantry, ingredient))}
          onClear={() => setPantry([])}
        />
        <main>
          <Header
            user={user}
            onLogin={() => setView('login')}
            onLogout={handleLogout}
            filters={filters}
            setFilters={setFilters}
          />
          <div className="content">
            {view === 'recipes' ? (
              <Recipes
                results={results}
                hasPantry={pantry.length > 0}
                favOnly={filters.favOnly}
                fav={fav}
                onToggleFav={toggleFav}
                onOpen={setSelected}
              />
            ) : (
              <AuthForm
                key={view}
                mode={view}
                onSubmit={handleAuth}
                onSwitch={() => setView(view === 'login' ? 'register' : 'login')}
              />
            )}
          </div>
        </main>
      </div>

      <RecipeDialog
        recipe={selected}
        pantry={pantry}
        isFav={selected ? fav.includes(selected.n) : false}
        onToggleFav={toggleFav}
        onClose={() => setSelected(null)}
      />
    </>
  )
}
