import { useState, useEffect } from 'react'

// Works like useState, but the value is also saved in the browser,
// so it is still there after a refresh.
export default function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const saved = localStorage.getItem(key)
      return saved === null ? initial : JSON.parse(saved)
    } catch {
      return initial
    }
  })

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value))
    } catch {
      // storage unavailable: ignore
    }
  }, [key, value])

  return [value, setValue]
}
