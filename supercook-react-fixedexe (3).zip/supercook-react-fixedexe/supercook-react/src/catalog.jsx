import { createContext, useContext, useEffect, useState } from 'react'
import { getRecipes, getMeta } from './api.js'

// The lists the website is built from: recipes, meal types, cuisines, ingredients (by category name),
// rating and size limits. ALL of it comes from the database through the API; nothing is built in.
//   status: 'loading' | 'ready' | 'error'
const EMPTY = {
  status: 'loading',
  error: '',
  recipes: [],
  meals: [],
  cuisines: [],
  ingredients: {}, // { 'Animal Proteins': ['Chicken', ...], ... }
  aliases: {},
  ratings: [], // rating values that exist in the database
  limits: { maxMinutes: 0, maxIngredients: 0 },
}

const CatalogContext = createContext(EMPTY)

export function CatalogProvider({ children }) {
  const [catalog, setCatalog] = useState(EMPTY)

  useEffect(() => {
    let cancelled = false
    Promise.all([getRecipes(), getMeta()])
      .then(([recipes, meta]) => {
        if (cancelled) return
        setCatalog({ ...EMPTY, ...meta, recipes, status: 'ready' })
      })
      .catch((err) => !cancelled && setCatalog({ ...EMPTY, status: 'error', error: err.message }))
    return () => {
      cancelled = true
    }
  }, [])

  return <CatalogContext.Provider value={catalog}>{children}</CatalogContext.Provider>
}

export const useCatalog = () => useContext(CatalogContext)
