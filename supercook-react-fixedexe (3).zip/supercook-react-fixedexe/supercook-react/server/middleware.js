import jwt from 'jsonwebtoken'
import { query } from './db.js'

// An error that is safe to show to the person using the website
export class HttpError extends Error {
  constructor(status, message) {
    super(message)
    this.status = status
    this.expose = true
  }
}

// The users table (supercook_db.sql) only has email + password, so:
//  - the name shown on the website is the part of the email before the @
//  - admins are the emails listed in ADMIN_EMAILS in .env (comma separated)
export const displayName = (email) => String(email || '').split('@')[0]
const adminEmails = () =>
  new Set(String(process.env.ADMIN_EMAILS || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean))
export const isAdminEmail = (email) => adminEmails().has(String(email || '').toLowerCase())

// Blocks requests that don't carry a valid login token. Sets req.user.
export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : ''
  let payload
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET)
  } catch {
    return res.status(401).json({ error: 'Please log in first' })
  }
  // Make sure the account still exists (it may have been deleted since the token was issued)
  const [user] = await query('SELECT user_id AS id, email FROM users WHERE user_id = ?', [payload.id])
  if (!user) return res.status(401).json({ error: 'Please log in first' })
  req.user = { ...user, username: displayName(user.email), is_admin: isAdminEmail(user.email) }
  next()
}

// Only for admin accounts (used for adding / editing / deleting recipes and photos)
export function requireAdmin(req, res, next) {
  if (!req.user?.is_admin) return res.status(403).json({ error: 'Admins only. Add your email to ADMIN_EMAILS in .env.' })
  next()
}

// Very small in-memory limiter, used on login/register to slow down password guessing
export function rateLimit({ windowMs, max }) {
  const hits = new Map()
  setInterval(() => {
    const now = Date.now()
    for (const [key, rec] of hits) if (now > rec.reset) hits.delete(key)
  }, windowMs).unref()

  return (req, res, next) => {
    const now = Date.now()
    const rec = hits.get(req.ip)
    if (!rec || now > rec.reset) {
      hits.set(req.ip, { count: 1, reset: now + windowMs })
      return next()
    }
    if (++rec.count > max) {
      return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' })
    }
    next()
  }
}

// Last stop for any error, so the server answers with JSON instead of crashing
export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err)
  if (err.expose && err.status) return res.status(err.status).json({ error: err.message })
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' })
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'That file is too large (max 5 MB).' })
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'That already exists' })
  if (['ECONNREFUSED', 'PROTOCOL_CONNECTION_LOST', 'ER_ACCESS_DENIED_ERROR', 'ER_BAD_DB_ERROR', 'ETIMEDOUT'].includes(err.code)) {
    console.error('Database problem:', err.code)
    return res.status(503).json({ error: 'The database is unavailable right now' })
  }
  if (['ER_NO_SUCH_TABLE', 'ER_BAD_FIELD_ERROR'].includes(err.code)) {
    console.error('Database layout problem:', err.sqlMessage)
    return res.status(500).json({ error: 'The database does not match supercook_db.sql. Run: npm run db:setup' })
  }
  console.error(err)
  res.status(500).json({ error: 'Something went wrong on the server' })
}
