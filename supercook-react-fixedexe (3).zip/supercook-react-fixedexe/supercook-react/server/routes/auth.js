import { Router } from 'express'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { query } from '../db.js'
import { requireAuth, rateLimit, displayName, isAdminEmail } from '../middleware.js'

const router = Router()
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 })

// The users table (supercook_db.sql) is: user_id, email, password, created_at.
// So an account is identified by its email; `password` holds the bcrypt hash.
const sign = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: '7d' })

// Used so an unknown email takes as long to reject as a wrong password
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10)

// POST /api/register   { email, password, username? }  ->  { username, token }
// (username is accepted because the website sends it, but the database has no column for it:
//  the name shown is the part of the email before the @)
router.post('/register', limiter, async (req, res) => {
  const email = String(req.body?.email ?? '').trim().toLowerCase()
  const password = String(req.body?.password ?? '')

  if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 255) {
    return res.status(400).json({ error: 'Enter a valid email address.' })
  }
  if (password.length < 6 || password.length > 72) {
    return res.status(400).json({ error: 'Password must be 6 to 72 characters.' })
  }

  const [taken] = await query('SELECT user_id FROM users WHERE email = ?', [email])
  if (taken) return res.status(409).json({ error: 'That email is already registered.' })

  const hash = await bcrypt.hash(password, 10) // the plain password is never stored
  const result = await query('INSERT INTO users (email, password) VALUES (?, ?)', [email, hash])
  res.status(201).json({ username: displayName(email), token: sign(result.insertId) })
})

// POST /api/login   { email (the website sends it as "username"), password }  ->  { username, token }
router.post('/login', limiter, async (req, res) => {
  const email = String(req.body?.email ?? req.body?.username ?? '').trim().toLowerCase()
  const password = String(req.body?.password ?? '')

  const [user] = await query('SELECT user_id AS id, email, password FROM users WHERE email = ?', [email])
  const ok = await bcrypt.compare(password, user ? user.password : DUMMY_HASH)
  if (!user || !ok) return res.status(401).json({ error: 'Wrong email or password.' })

  res.json({ username: displayName(user.email), token: sign(user.id) })
})

// GET /api/me  ->  the logged-in user (handy for restoring a session after a refresh)
router.get('/me', requireAuth, (req, res) => {
  res.json({ username: req.user.username, email: req.user.email, isAdmin: isAdminEmail(req.user.email) })
})

export default router
