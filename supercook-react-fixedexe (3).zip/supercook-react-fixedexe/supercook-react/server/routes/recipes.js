import { Router } from 'express'
import { requireAuth, requireAdmin } from '../middleware.js'
import { query } from '../db.js'
import express from 'express'
import { getAllRecipes, getRecipe, saveRecipe, getMeta, getStoredImage, setImage } from '../recipeStore.js'
import { IMAGE_TYPES, MAX_IMAGE_BYTES, looksLikeImage, saveUpload, removeUpload } from '../uploads.js'

const router = Router()

// GET /api/recipes  ->  [{ id, n, i, opt, ing, t, r, meal, cuisine, s, e, url, img, ... }, ...]
router.get('/recipes', async (req, res) => {
  res.json(await getAllRecipes())
})

// GET /api/recipes/:id
router.get('/recipes/:id', async (req, res) => {
  const recipe = await getRecipe(Number(req.params.id))
  if (!recipe) return res.status(404).json({ error: 'Recipe not found' })
  res.json(recipe)
})

// GET /api/meta  ->  { meals, cuisines, ingredients: { Category: [names] }, ratings, limits }
// Everything comes from the database: add a recipe with a new cuisine or meal type, or a new
// ingredient, and it shows up on the website by itself.
router.get('/meta', async (req, res) => {
  res.json(await getMeta())
})

// Checks a recipe sent by an admin. Returns { data } if fine, or { error }.
//   { name, meal, cuisine, ingredients: [{ name } | "Name"], time? (total minutes),
//     source_url? (the recipe link), image_url? (a photo link), rating? (0 to 5) }
// (the database stores no quantities, units, servings or optional flags, so those are not accepted)
function cleanRecipe(body = {}) {
  const text = (v) => String(v ?? '').trim()
  const num = (v, fallback) => (v === undefined || v === null || v === '' ? fallback : Number(v))

  const name = text(body.name)
  const meal = text(body.meal)
  const cuisine = text(body.cuisine)
  const time = num(body.time, 0) // recipe time = total minutes to make it
  const rating = num(body.rating, null)
  const image_url = text(body.image_url)
  const source_url = text(body.source_url ?? body.recipe_url)

  const ingredients = (Array.isArray(body.ingredients) ? body.ingredients : []).map((x) => ({
    name: text(typeof x === 'string' ? x : x?.name),
  }))

  if (!name || name.length > 180) return { error: 'name is required (max 180 characters).' }
  if (!meal || meal.length > 100) return { error: 'meal is required (max 100 characters).' }
  if (!cuisine || cuisine.length > 100) return { error: 'cuisine is required (max 100 characters).' }
  if (!ingredients.length || ingredients.length > 60 || ingredients.some((x) => !x.name || x.name.length > 160)) {
    return { error: 'ingredients: send between 1 and 60 items, each with a name.' }
  }
  if (!Number.isInteger(time) || time < 0 || time > 1440) return { error: 'time must be a whole number of minutes from 0 to 1440.' }
  if (rating !== null && (!Number.isFinite(rating) || rating < 0 || rating > 5)) return { error: 'rating must be a number from 0 to 5.' }
  if (source_url && (!/^https?:\/\/\S+$/i.test(source_url) || source_url.length > 500)) {
    return { error: 'The recipe link must start with http:// or https:// (max 500 characters).' }
  }
  if (image_url && (image_url.length > 500 || !(/^https?:\/\/\S+$/i.test(image_url) || /^\/uploads\/[\w.-]+$/.test(image_url)))) {
    return { error: 'The image must be an http(s):// link (or upload a file instead).' }
  }

  return {
    data: {
      name, meal, cuisine, ingredients, time,
      rating: rating === null ? null : Math.round(rating * 100) / 100,
      image_url: image_url || null,
      source_url: source_url || null,
    },
  }
}

async function save(req, res, id) {
  const { data, error } = cleanRecipe(req.body)
  if (error) return res.status(400).json({ error })
  // keep the photo that is already there when an update doesn't mention one
  if (id && req.body?.image_url === undefined) data.image_url = (await getStoredImage(id)) || null
  try {
    const savedId = await saveRecipe(data, id)
    if (!savedId) return res.status(404).json({ error: 'Recipe not found' })
    res.status(id ? 200 : 201).json(await getRecipe(savedId))
  } catch (err) {
    if (err.code === 'DUPLICATE_NAME' || err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'A recipe with that name already exists.' })
    throw err
  }
}

// POST /api/recipes   (admin)
router.post('/recipes', requireAuth, requireAdmin, (req, res) => save(req, res, null))

// PUT /api/recipes/:id   (admin) replaces the whole recipe, so send every field
router.put('/recipes/:id', requireAuth, requireAdmin, (req, res) => save(req, res, Number(req.params.id)))

// DELETE /api/recipes/:id   (admin)
router.delete('/recipes/:id', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id)
  const photo = await getStoredImage(id)
  const result = await query('DELETE FROM recipes WHERE recipe_id = ?', [id])
  if (!result.affectedRows) return res.status(404).json({ error: 'Recipe not found' })
  removeUpload(photo)
  res.json({ ok: true })
})

// POST /api/recipes/:id/image   (admin) the body IS the picture (Content-Type: image/jpeg, png, webp or gif, max 5 MB).
// Saves it in server/uploads/ and stores "/uploads/<file>" in recipes.image_url. Replaces any earlier photo.
const rawImage = express.raw({ type: Object.keys(IMAGE_TYPES), limit: MAX_IMAGE_BYTES })
router.post('/recipes/:id/image', requireAuth, requireAdmin, rawImage, async (req, res) => {
  const id = Number(req.params.id)
  const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase()
  if (!IMAGE_TYPES[type]) return res.status(415).json({ error: 'Send a JPEG, PNG, WebP or GIF picture.' })
  if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ error: 'No picture received.' })
  if (!looksLikeImage(req.body, type)) return res.status(400).json({ error: 'That file is not a real ' + IMAGE_TYPES[type].toUpperCase() + ' picture.' })

  const old = await getStoredImage(id)
  if (old === null) return res.status(404).json({ error: 'Recipe not found' })
  const path = saveUpload(req.body, type, id)
  await setImage(id, path)
  removeUpload(old)
  res.json(await getRecipe(id))
})

// PUT /api/recipes/:id/image   (admin) { image_url: "https://..." } use a picture from the web instead
router.put('/recipes/:id/image', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id)
  const link = String(req.body?.image_url ?? '').trim()
  if (!/^https?:\/\/\S+$/i.test(link) || link.length > 500) return res.status(400).json({ error: 'image_url must be an http(s):// link.' })
  const old = await getStoredImage(id)
  if (old === null) return res.status(404).json({ error: 'Recipe not found' })
  await setImage(id, link)
  removeUpload(old)
  res.json(await getRecipe(id))
})

// DELETE /api/recipes/:id/image   (admin) back to the emoji
router.delete('/recipes/:id/image', requireAuth, requireAdmin, async (req, res) => {
  const id = Number(req.params.id)
  const old = await getStoredImage(id)
  if (old === null) return res.status(404).json({ error: 'Recipe not found' })
  await setImage(id, null)
  removeUpload(old)
  res.json(await getRecipe(id))
})

export default router
