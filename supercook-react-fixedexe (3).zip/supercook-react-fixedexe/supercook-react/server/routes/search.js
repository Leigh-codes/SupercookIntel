import { Router } from 'express'
import { matchRecipes } from '../search/matching.js'
import { searchExternal } from '../search/external.js'
import { getAllRecipes, canonicalIngredients } from '../recipeStore.js'
import { rateLimit } from '../middleware.js'

const router = Router()
const MIN_LOCAL = 8 // top up with outside recipes when our own database gives fewer than this
const limiter = rateLimit({ windowMs: 60 * 1000, max: 90 }) // protects the outside API's free quota

const list = (v) => (v ? String(v).split(',').map((s) => s.trim()).filter(Boolean) : [])

// GET /api/search?pantry=Pork,Garlic&exclude=&meal=&cuisine=&maxIng=&time=&rating=
// -> [{ r: recipe, have: [matched ingredients] }, ...]     (add &external=0 to skip the outside search)
router.get('/search', limiter, async (req, res) => {
  const filters = {
    exclude: list(req.query.exclude),
    meal: list(req.query.meal),
    cuisine: list(req.query.cuisine),
    maxIng: Number(req.query.maxIng) || 99,
    time: Number(req.query.time) || 1440,
    rating: Number(req.query.rating) || 0,
  }
  let pantry = list(req.query.pantry).slice(0, 200)
  if (!pantry.length) return res.json([])

  // Our own recipes (errors, e.g. MySQL being down, go to the error handler as a 503)
  const ours = await getAllRecipes()
  pantry = await canonicalIngredients(pantry) // "scallion" -> "Spring onions"
  filters.exclude = await canonicalIngredients(filters.exclude)

  let results = matchRecipes(ours, pantry, filters)

  if (results.length < MIN_LOCAL && req.query.external !== '0') {
    let extra = []
    try {
      extra = await searchExternal(pantry, filters)
    } catch (err) {
      console.warn('Outside search skipped:', err.message) // never break the page over this
    }
    const seen = new Set(ours.map((r) => r.n.toLowerCase()))
    const fresh = extra.filter((r) => !seen.has(r.n.toLowerCase()))
    results = matchRecipes([...ours, ...fresh], pantry, filters)
  }

  res.json(results)
})

export default router
