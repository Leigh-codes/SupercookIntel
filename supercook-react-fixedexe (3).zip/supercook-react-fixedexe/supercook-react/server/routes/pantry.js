import { Router } from 'express'
import { query, transaction } from '../db.js'
import { requireAuth } from '../middleware.js'
import { canonicalIngredients } from '../recipeStore.js'

const router = Router()
router.use('/pantry', requireAuth) // every pantry route needs a login

const names = async (userId) =>
  (
    await query(
      `SELECT i.ingredient_name AS name FROM user_pantry p
       JOIN ingredients i ON i.ingredient_id = p.ingredient_id
       WHERE p.user_id = ? ORDER BY p.added_at, i.ingredient_name`,
      [userId]
    )
  ).map((r) => r.name)

// GET /api/pantry  ->  ["Pork", "Garlic", ...]
router.get('/pantry', async (req, res) => {
  res.json(await names(req.user.id))
})

// PUT /api/pantry   { items: ["Pork", ...] }  replaces the whole saved pantry.
// Alias names ("scallion") are accepted; names that aren't ingredients are skipped.
router.put('/pantry', async (req, res) => {
  const raw = Array.isArray(req.body?.items) ? req.body.items.map((x) => String(x).trim()).filter(Boolean) : null
  if (!raw || raw.length > 500) return res.status(400).json({ error: 'Send { "items": [ ... ] } (max 500).' })
  const items = await canonicalIngredients(raw)

  await transaction(async (q) => {
    await q('DELETE FROM user_pantry WHERE user_id = ?', [req.user.id])
    if (!items.length) return
    const found = await q('SELECT ingredient_id AS id FROM ingredients WHERE ingredient_name IN (?)', [items])
    if (found.length) {
      await q('INSERT IGNORE INTO user_pantry (user_id, ingredient_id) VALUES ?', [found.map((f) => [req.user.id, f.id])])
    }
  })
  res.json(await names(req.user.id))
})

// POST /api/pantry/:name   adds one ingredient
router.post('/pantry/:name', async (req, res) => {
  const [name] = await canonicalIngredients([req.params.name])
  const [ing] = await query('SELECT ingredient_id AS id FROM ingredients WHERE ingredient_name = ?', [name])
  if (!ing) return res.status(404).json({ error: 'Unknown ingredient' })
  await query('INSERT IGNORE INTO user_pantry (user_id, ingredient_id) VALUES (?, ?)', [req.user.id, ing.id])
  res.json({ ok: true })
})

// DELETE /api/pantry/:name   removes one ingredient
router.delete('/pantry/:name', async (req, res) => {
  const [name] = await canonicalIngredients([req.params.name])
  await query(
    `DELETE FROM user_pantry WHERE user_id = ?
     AND ingredient_id = (SELECT ingredient_id FROM ingredients WHERE ingredient_name = ?)`,
    [req.user.id, name]
  )
  res.json({ ok: true })
})

// DELETE /api/pantry   empties the pantry
router.delete('/pantry', async (req, res) => {
  await query('DELETE FROM user_pantry WHERE user_id = ?', [req.user.id])
  res.json({ ok: true })
})

export default router
