// Dish photos uploaded by an admin are saved in server/uploads/ and served at /uploads/<file>.
// recipes.image_url then holds the path "/uploads/<file>" (or any https:// link if you paste one instead).
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

export const UPLOAD_DIR = path.join(path.dirname(fileURLToPath(import.meta.url)), 'uploads')
fs.mkdirSync(UPLOAD_DIR, { recursive: true })

export const IMAGE_TYPES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' }
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024

// Does the file really start like the type it claims to be? (SVG and everything else is refused)
export function looksLikeImage(buf, type) {
  const at = (i, s) => buf.subarray(i, i + s.length).toString('latin1') === s
  if (type === 'image/jpeg') return buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff
  if (type === 'image/png') return buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
  if (type === 'image/gif') return at(0, 'GIF87a') || at(0, 'GIF89a')
  if (type === 'image/webp') return at(0, 'RIFF') && at(8, 'WEBP')
  return false
}

export function saveUpload(buf, type, recipeId) {
  const name = `recipe-${recipeId}-${Date.now().toString(36)}.${IMAGE_TYPES[type]}`
  fs.writeFileSync(path.join(UPLOAD_DIR, name), buf)
  return `/uploads/${name}`
}

// Delete the file behind an image_url, but only if it is one of ours
export function removeUpload(imageUrl) {
  if (!imageUrl || !imageUrl.startsWith('/uploads/')) return
  const file = path.basename(imageUrl)
  fs.rmSync(path.join(UPLOAD_DIR, file), { force: true })
}
