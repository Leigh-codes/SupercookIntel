import 'dotenv/config'
import mysql from 'mysql2/promise'

// One shared pool of connections to MySQL (XAMPP / Laragon defaults: root, no password, port 3306)
export const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'supercook_db',
  charset: 'utf8mb4',
  waitForConnections: true,
  connectionLimit: 10,
})

// Run SQL, get the rows back. Values go in the ? slots, never into the SQL text.
export async function query(sql, params = []) {
  const [rows] = await pool.query(sql, params)
  return rows
}

// Run several statements as one all-or-nothing unit.
// fn receives a function q(sql, params) that works like query().
export async function transaction(fn) {
  const conn = await pool.getConnection()
  try {
    await conn.beginTransaction()
    const q = async (sql, params = []) => (await conn.query(sql, params))[0]
    const result = await fn(q)
    await conn.commit()
    return result
  } catch (err) {
    await conn.rollback()
    throw err
  } finally {
    conn.release()
  }
}
