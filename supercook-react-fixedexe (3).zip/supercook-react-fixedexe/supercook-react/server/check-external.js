// Tests the outside recipe search:   npm run api:check [-- Ingredient ...]
// Example:                           npm run api:check -- Chicken Garlic
import 'dotenv/config'
import { searchExternal, externalProvider } from './search/external.js'

const provider = externalProvider()
if (!provider) {
  console.log('Outside search is switched off (EXTERNAL_PROVIDER=none, or EXTERNAL_PROVIDER=spoonacular with no SPOONACULAR_KEY).')
  console.log('For the no-signup provider set EXTERNAL_PROVIDER=themealdb (or leave it as auto) in .env.')
  process.exit(1)
}

const pantry = process.argv.slice(2).length ? process.argv.slice(2) : ['Chicken', 'Garlic', 'Onion']
console.log(`Provider: ${provider}`)
console.log(`Searching for: ${pantry.join(', ')} ...`)

try {
  const results = await searchExternal(pantry, { exclude: [], time: 1440 })
  if (!results.length) {
    console.log('The API answered, but found no recipes for those ingredients. Try other ingredients.')
  } else {
    console.log(`OK: ${results.length} recipes came back. First few:`)
    for (const r of results.slice(0, 5)) {
      const time = r.t ? `${r.t} min` : 'time unknown'
      console.log(`  - ${r.n}  [${r.s || 'unknown site'}]  ${r.meal}/${r.cuisine}  ${time}  ${r.i.length} ingredients`)
    }
    console.log('\nOutside search is working. /api/search will now top up from it.')
  }
} catch (err) {
  const hints = {
    401: 'The key was rejected. Re-copy it into .env (no spaces or quotes), then run this again.',
    402: 'The free daily limit is used up. Try again tomorrow, or upgrade the plan.',
    429: 'Too many requests too quickly. Wait a minute and try again.',
  }
  console.error(`Failed: ${err.message}`)
  console.error(hints[err.status] || 'Check your internet connection (and that nothing is blocking the provider\'s website).')
  process.exit(1)
}
