// Remembers answers for a while so the same search doesn't hit the outside API twice.
// (In memory, so it resets whenever the server restarts.)
const store = new Map()
const MAX_ENTRIES = 500

export async function cached(key, ttlMs, loader) {
  const hit = store.get(key)
  if (hit && Date.now() - hit.at < ttlMs) return hit.value

  const value = await loader() // if this throws, nothing is cached
  store.delete(key)
  store.set(key, { value, at: Date.now() })
  if (store.size > MAX_ENTRIES) store.delete(store.keys().next().value) // drop the oldest
  return value
}
