// Outside recipe search. Two providers, both return recipes in the SAME shape as our own database
// (see recipeStore.js), so the website treats them identically:
//
//   themealdb    https://www.themealdb.com   no signup; uses the public test key "1" (fine for development;
//                                            for a public site, get a key from them and set THEMEALDB_KEY)
//   spoonacular  https://spoonacular.com     needs a free key in SPOONACULAR_KEY; richer data (time, score)
//
// EXTERNAL_PROVIDER in .env:  auto (default: spoonacular if a key is set, else themealdb) | themealdb | spoonacular | none
import { cached } from './cache.js'

const MAX_TERMS = 3 // search with at most 3 pantry items (the 3 most recently added)
const MAX_DETAILS = 10 // TheMealDB: how many candidate recipes to open in full
const EMOJI = { Breakfast: '🍳', Lunch: '🥗', Dinner: '🍽️', Snack: '🍿', Dessert: '🍰' }

const ttl = () => (Number(process.env.EXTERNAL_CACHE_HOURS) || 1) * 60 * 60 * 1000

export function externalProvider() {
  const want = (process.env.EXTERNAL_PROVIDER || 'auto').toLowerCase()
  if (want === 'none') return null
  if (want === 'spoonacular') return process.env.SPOONACULAR_KEY ? 'spoonacular' : null
  if (want === 'themealdb') return 'themealdb'
  return process.env.SPOONACULAR_KEY ? 'spoonacular' : 'themealdb'
}

// ---------- shared helpers ----------

async function getJson(url, options = {}) {
  const res = await fetch(url, { ...options, signal: AbortSignal.timeout(7000) })
  if (!res.ok) {
    const err = new Error(`external search failed (${res.status})`)
    err.status = res.status
    throw err
  }
  return res.json()
}

// "chicken breasts" -> "Chicken" when Chicken is in the pantry, so matching works.
// Otherwise just capitalise it.
function canonical(name, pantry) {
  const clean = String(name).trim()
  const match = pantry
    .filter((p) => new RegExp(`\\b${p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}s?\\b`, 'i').test(clean))
    .sort((a, b) => b.length - a.length)[0]
  return match || clean.charAt(0).toUpperCase() + clean.slice(1)
}

const siteOf = (url, fallback = '') => {
  try {
    return new URL(url).hostname.replace(/^www\./, '') // shows like "bbcgoodfood.com"
  } catch {
    return fallback
  }
}

const stripHtml = (s) =>
  String(s || '')
    .replace(/<\/(li|p|div)>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/\n{2,}/g, '\n')
    .trim()

// ---------- TheMealDB ----------

const MDB = () => `https://www.themealdb.com/api/json/v1/${process.env.THEMEALDB_KEY || '1'}`

function mdbMeal(category = '') {
  const c = category.toLowerCase()
  if (c === 'breakfast') return 'Breakfast'
  if (c === 'dessert') return 'Dessert'
  if (c === 'starter' || c === 'side' || c === 'miscellaneous') return 'Snack'
  return 'Dinner'
}

export function normalizeMealDb(m, pantry) {
  const ing = []
  for (let k = 1; k <= 20; k++) {
    const name = String(m[`strIngredient${k}`] ?? '').trim()
    if (!name) continue
    ing.push({ name: canonical(name, pantry), quantity: null, unit: String(m[`strMeasure${k}`] ?? '').trim(), optional: false })
  }
  const names = [...new Set(ing.map((x) => x.name))]
  const meal = mdbMeal(m.strCategory)
  const url = m.strSource || `https://www.themealdb.com/meal/${m.idMeal}`
  const area = m.strArea && m.strArea !== 'Unknown' ? m.strArea : 'Other'
  return {
    ext: true,
    n: m.strMeal,
    e: EMOJI[meal],
    s: siteOf(url, 'themealdb.com'),
    url,
    img: m.strMealThumb || '',
    meal,
    cuisine: area,
    t: 0, // TheMealDB doesn't give cooking time or ratings
    r: 0,
    i: names,
    opt: [],
    ing: ing.filter((x, k) => ing.findIndex((y) => y.name === x.name) === k),
    steps: String(m.strInstructions || '').replace(/\r/g, '').trim(),
    servings: 0,
  }
}

async function searchMealDb(pantry) {
  const terms = pantry.slice(-MAX_TERMS)

  // 1. which recipes use each ingredient (TheMealDB's free tier takes one ingredient per call)
  const settled = await Promise.allSettled(
    terms.map((t) =>
      cached(`mdb:filter:${t.toLowerCase()}`, ttl(), async () => {
        const data = await getJson(`${MDB()}/filter.php?i=${encodeURIComponent(t.trim().replace(/\s+/g, '_'))}`)
        return Array.isArray(data.meals) ? data.meals : [] // "no data found" comes back as null or a string
      })
    )
  )
  // every call failed = a real problem (offline, blocked, rate limited), not "no matches"
  if (settled.length && settled.every((x) => x.status === 'rejected')) throw settled[0].reason
  const lists = settled.map((x) => (x.status === 'fulfilled' ? x.value : []))

  // 2. recipes that use the most of your ingredients first
  const hits = new Map()
  for (const list of lists) for (const x of list) hits.set(x.idMeal, (hits.get(x.idMeal) || 0) + 1)
  const ids = [...hits.entries()].sort((a, b) => b[1] - a[1]).slice(0, MAX_DETAILS).map(([id]) => id)
  if (!ids.length) return []

  // 3. open each one in full (ingredients, instructions, photo)
  const full = await Promise.allSettled(
    ids.map((id) =>
      cached(`mdb:meal:${id}`, ttl(), async () => {
        const data = await getJson(`${MDB()}/lookup.php?i=${id}`)
        return Array.isArray(data.meals) ? data.meals[0] : null
      })
    )
  )
  const meals = full.filter((x) => x.status === 'fulfilled' && x.value).map((x) => x.value)
  if (!meals.length && full.some((x) => x.status === 'rejected')) throw full.find((x) => x.status === 'rejected').reason
  return meals.map((m) => normalizeMealDb(m, pantry))
}

// ---------- Spoonacular ----------

const SPOON_URL = 'https://api.spoonacular.com/recipes/complexSearch'

// The outside API's dish types -> the five meal types the filters use
function spoonMeal(dishTypes = []) {
  const t = dishTypes.map((d) => d.toLowerCase())
  if (t.includes('breakfast') || t.includes('brunch')) return 'Breakfast'
  if (t.includes('dessert')) return 'Dessert'
  if (t.some((d) => ['snack', 'fingerfood', 'appetizer', 'antipasti'].includes(d))) return 'Snack'
  if (t.includes('lunch')) return 'Lunch'
  return 'Dinner'
}

export function normalizeSpoonacular(x, pantry) {
  const meal = spoonMeal(x.dishTypes)
  const url = x.sourceUrl || x.spoonacularSourceUrl || ''
  const cuisines = x.cuisines || []
  const ing = (x.extendedIngredients || []).map((g) => ({
    name: canonical(g.nameClean || g.name, pantry),
    quantity: Number.isFinite(g.amount) ? Math.round(g.amount * 100) / 100 : null,
    unit: g.unit || '',
    optional: false,
  }))
  return {
    ext: true,
    n: x.title,
    e: EMOJI[meal],
    s: siteOf(url, x.sourceName || ''),
    url,
    img: x.image || '',
    meal,
    cuisine: cuisines[0] || 'Other',
    t: x.readyInMinutes || 0,
    r: Math.min(5, Math.max(1, Math.round((x.spoonacularScore || 0) / 20))), // 0-100 -> 1-5 stars
    i: [...new Set(ing.map((g) => g.name))],
    opt: [],
    ing,
    steps: stripHtml(x.instructions),
    servings: x.servings || 0,
  }
}

async function searchSpoonacular(pantry, filters) {
  const terms = pantry.slice(-MAX_TERMS).map((p) => p.toLowerCase())
  const exclude = filters.exclude.map((e) => e.toLowerCase())

  const params = new URLSearchParams({
    includeIngredients: terms.join(','),
    number: '12',
    sort: 'max-used-ingredients',
    addRecipeInformation: 'true',
    fillIngredients: 'true',
  })
  if (exclude.length) params.set('excludeIngredients', exclude.join(','))
  if (filters.time < 1440) params.set('maxReadyTime', String(filters.time))

  // meal / cuisine / rating are applied afterwards, so they don't need their own API call
  return cached(`spoon:${params}`, ttl(), async () => {
    const data = await getJson(`${SPOON_URL}?${params}`, { headers: { 'x-api-key': process.env.SPOONACULAR_KEY } })
    return (data.results || []).map((x) => normalizeSpoonacular(x, pantry))
  })
}

// ---------- entry point ----------

// Throws if the outside API fails (the route catches it and carries on without it)
export async function searchExternal(pantry, filters) {
  const provider = externalProvider()
  if (!provider || !pantry.length) return []
  return provider === 'spoonacular' ? searchSpoonacular(pantry, filters) : searchMealDb(pantry)
}
