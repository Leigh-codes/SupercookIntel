// "What can I make?" rules: which recipes use the pantry and pass every filter,
// best match first. (Same rules the website uses on its own.)
//   r.i   = required ingredients (these are what count as "matched")
//   r.opt = optional ingredients (never counted, but an excluded one still hides the recipe)
const lc = (s) => String(s).toLowerCase()

export function matchRecipes(recipes, pantry, f, { requirePantry = true } = {}) {
  const have = new Set(pantry.map(lc))
  const out = new Set(f.exclude.map(lc))
  const ratio = (x) => (x.r.i.length ? x.have.length / x.r.i.length : 0)

  return recipes
    .map((r) => ({ r, have: r.i.filter((x) => have.has(lc(x))) }))
    .filter(
      ({ r, have }) =>
        (have.length || !requirePantry) &&
        ![...r.i, ...(r.opt || [])].some((x) => out.has(lc(x))) &&
        (!f.meal.length || f.meal.includes(r.meal)) &&
        (!f.cuisine.length || f.cuisine.includes(r.cuisine)) &&
        r.i.length <= f.maxIng &&
        r.t <= f.time &&
        r.r >= f.rating
    )
    .sort((a, b) => ratio(b) - ratio(a) || b.have.length - a.have.length || (b.r.rating ?? b.r.r) - (a.r.rating ?? a.r.r))
}
