import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import { pool, query } from './db.js'
import { errorHandler } from './middleware.js'
import authRoutes from './routes/auth.js'
import recipeRoutes from './routes/recipes.js'
import pantryRoutes from './routes/pantry.js'
import favoriteRoutes from './routes/favorites.js'
import searchRoutes from './routes/search.js'
import { externalProvider } from './search/external.js'
import { UPLOAD_DIR } from './uploads.js'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

// Refuse to start without a real secret: it signs every login token
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 16 || process.env.JWT_SECRET.startsWith('change-me')) {
  console.error('JWT_SECRET is missing or too weak. Set a long random value in .env (see .env.example).')
  process.exit(1)
}

const app = express()
app.disable('x-powered-by')

// Which websites may call this API (the Vite dev site by default)
const origins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173').split(',').map((s) => s.trim())
app.use(cors({ origin: origins }))
app.use(express.json({ limit: '100kb' }))

// Dish photos uploaded by an admin, and the small page to upload them from (http://localhost:3001/admin)
app.use('/uploads', (req, res, next) => {
  res.set('Cross-Origin-Resource-Policy', 'cross-origin') // the website runs on another port
  res.set('X-Content-Type-Options', 'nosniff')
  next()
}, express.static(UPLOAD_DIR, { index: false, dotfiles: 'ignore' }))
app.get('/admin', (req, res) => res.sendFile(path.join(path.dirname(fileURLToPath(import.meta.url)), 'admin.html')))

app.get('/api/health', async (req, res) => {
  try {
    await query('SELECT 1')
    res.json({ ok: true, database: 'connected', externalSearch: externalProvider() || 'off' })
  } catch {
    res.status(503).json({ ok: false, database: 'unreachable', externalSearch: externalProvider() || 'off' })
  }
})

app.use('/api', authRoutes)
app.use('/api', recipeRoutes)
app.use('/api', pantryRoutes)
app.use('/api', favoriteRoutes)
app.use('/api', searchRoutes)

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }))
app.use(errorHandler)

const port = Number(process.env.PORT) || 3001
const server = app.listen(port, async () => {
  console.log(`SuperCook API running on http://localhost:${port}`)
  try {
    await query('SELECT 1')
    console.log(`Database "${process.env.DB_NAME || 'supercook_db'}": connected`)
  } catch (err) {
    console.warn(`Database not reachable (${err.code || err.message}). Start MySQL (XAMPP / Laragon), then run: npm run db:setup`)
  }
})

// Close the database connections when you press Ctrl+C
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => server.close(() => pool.end().finally(() => process.exit(0))))
}
