import { query, transaction } from './db.js'

// Every recipe leaves the database in the shape the website uses (the website reads this shape):
//   n = name, i = ingredient names, t = total minutes, r = rating 0-5 (0 = not rated),
//   s = source site, e = emoji (only shown when there is no photo), meal, cuisine,
//   img = photo address, url = link to the recipe page
// plus extras for the recipe pop-up:
//   opt = [] (the database has no optional flag), ing = [{ name, quantity, unit, optional }],
//   steps (only outside recipes have instructions), servings, id, rating (the exact 0-5 value)
//
// Table / column names are the ones in database/supercook_db.sql:
//   recipes(recipe_id, recipe_name, cuisine_id, mealtype_id, rating, recipe_time, max_ingredients, recipe_url, image_url)
//   cuisines(cuisine_name)   mealtypes(mealtype_name)   recipe_ingredients(recipe_id, ingredient_id)
//   ingredients(ingredient_id, category_id, ingredient_name)   ingredient_categories(category_name)
const EMOJI = {
  Breakfast: '🍳', Brunch: '🥞', Lunch: '🥗', Dinner: '🍽️', Appetizer: '🥟', 'Side Dish': '🥔',
  Snack: '🍿', Dessert: '🍰', Beverage: '🥤', Soup: '🍲', Salad: '🥗',
}

// Photos uploaded through the API are stored as "/uploads/<file>". The website runs on another
// address than the API, so give it the full address of the API.
export const publicUrl = () => (process.env.PUBLIC_URL || `http://localhost:${Number(process.env.PORT) || 3001}`).replace(/\/+$/, '')
export const imageAddress = (v) => (v && v.startsWith('/uploads/') ? publicUrl() + v : v || '')

const siteOf = (url) => {
  try {
    return new URL(url).hostname.replace(/^www\./, '') // "https://www.kawalingpinoy.com/x" -> "kawalingpinoy.com"
  } catch {
    return ''
  }
}

const RECIPE_SQL = `
  SELECT r.recipe_id, r.recipe_name, m.mealtype_name AS meal_type, c.cuisine_name AS cuisine_type,
         r.rating, r.recipe_time, r.recipe_url, r.image_url
  FROM recipes r
  LEFT JOIN mealtypes m ON m.mealtype_id = r.mealtype_id
  LEFT JOIN cuisines c ON c.cuisine_id = r.cuisine_id`

const LINES_SQL = `
  SELECT ri.recipe_id, i.ingredient_name AS name
  FROM recipe_ingredients ri
  JOIN ingredients i ON i.ingredient_id = ri.ingredient_id`

function shape(row, lines = []) {
  const ing = lines.map((l) => ({ name: l.name, quantity: null, unit: '', optional: false }))
  const meal = row.meal_type || 'Other'
  const rating = row.rating === null || row.rating === undefined ? 0 : Number(row.rating)
  return {
    id: row.recipe_id,
    n: row.recipe_name,
    e: EMOJI[meal] || '🍽️',
    s: siteOf(row.recipe_url),
    url: row.recipe_url || '',
    img: imageAddress(row.image_url),
    meal,
    cuisine: row.cuisine_type || 'Other',
    t: Number(row.recipe_time) || 0, // recipe time: total minutes to make it
    r: rating, // exact 0-5 value from the database (the filter "4★ & up" means rating >= 4)
    rating,
    i: ing.map((x) => x.name),
    opt: [],
    ing,
    steps: '', // the database has no instructions; the recipe link has them
    servings: 0,
  }
}

function group(lines) {
  const byRecipe = new Map()
  for (const l of lines) {
    if (!byRecipe.has(l.recipe_id)) byRecipe.set(l.recipe_id, [])
    byRecipe.get(l.recipe_id).push(l)
  }
  return byRecipe
}

export async function getAllRecipes() {
  const [rows, lines] = await Promise.all([
    query(`${RECIPE_SQL} ORDER BY r.recipe_name`),
    query(`${LINES_SQL} ORDER BY i.ingredient_name`),
  ])
  const byRecipe = group(lines)
  return rows.map((r) => shape(r, byRecipe.get(r.recipe_id)))
}

export async function getRecipe(id) {
  const [row] = await query(`${RECIPE_SQL} WHERE r.recipe_id = ?`, [id])
  if (!row) return null
  const lines = await query(`${LINES_SQL} WHERE ri.recipe_id = ? ORDER BY i.ingredient_name`, [id])
  return shape(row, lines)
}

// The raw image_url stored for a recipe (used to delete the old file when a photo is replaced)
export async function getStoredImage(id) {
  const [row] = await query('SELECT image_url FROM recipes WHERE recipe_id = ?', [id])
  return row ? row.image_url || '' : null // null = no such recipe
}

export async function setImage(id, imageUrl) {
  const result = await query('UPDATE recipes SET image_url = ? WHERE recipe_id = ?', [imageUrl, id])
  return result.affectedRows > 0
}

// ---------- ingredients, cuisines, meal types ----------

// Where a brand-new ingredient name (typed by an admin) is filed until someone sorts it
const FALLBACK_CATEGORY = 'Specialty and Regional Ingredients'

// Make sure every ingredient exists (matching is case-insensitive); returns ids in the same
// order as `names`. q is the query function from transaction().
export async function ensureIngredients(q, names) {
  const ids = []
  for (const raw of names) {
    const name = String(raw).trim()
    const [found] = await q('SELECT ingredient_id AS id FROM ingredients WHERE ingredient_name = ?', [name])
    if (found) {
      ids.push(found.id)
      continue
    }
    const [cat] = await q('SELECT category_id AS id FROM ingredient_categories WHERE category_name = ?', [FALLBACK_CATEGORY])
    if (!cat) throw new Error(`Category "${FALLBACK_CATEGORY}" is missing from ingredient_categories`)
    const res = await q('INSERT INTO ingredients (category_id, ingredient_name) VALUES (?, ?)', [cat.id, name])
    ids.push(res.insertId)
  }
  return ids
}

// id of a cuisine / meal type by name; a new name is added to its table
async function ensureLookup(q, table, idCol, nameCol, name) {
  const [found] = await q(`SELECT ${idCol} AS id FROM ${table} WHERE ${nameCol} = ?`, [name])
  if (found) return found.id
  return (await q(`INSERT INTO ${table} (${nameCol}) VALUES (?)`, [name])).insertId
}

// Create (id = null) or update a recipe together with its ingredient list.
// data = { name, meal, cuisine, time, rating, image_url, source_url, ingredients: [{ name }] }
// Returns the recipe id, or null if id doesn't exist. Throws code 'DUPLICATE_NAME' for a repeated name.
export async function saveRecipe(data, id = null) {
  return transaction(async (q) => {
    const [clash] = await q('SELECT recipe_id FROM recipes WHERE recipe_name = ? AND recipe_id <> ?', [data.name, id || 0])
    if (clash) throw Object.assign(new Error('duplicate recipe name'), { code: 'DUPLICATE_NAME' })

    const cuisineId = await ensureLookup(q, 'cuisines', 'cuisine_id', 'cuisine_name', data.cuisine)
    const mealId = await ensureLookup(q, 'mealtypes', 'mealtype_id', 'mealtype_name', data.meal)

    const ids = await ensureIngredients(q, data.ingredients.map((x) => x.name))
    const unique = [...new Set(ids)] // same ingredient listed twice: keep it once

    let recipeId = id
    if (id) {
      const [exists] = await q('SELECT recipe_id FROM recipes WHERE recipe_id = ?', [id])
      if (!exists) return null
      await q(
        `UPDATE recipes SET recipe_name = ?, cuisine_id = ?, mealtype_id = ?, rating = ?, recipe_time = ?,
                max_ingredients = ?, recipe_url = ?, image_url = ?
         WHERE recipe_id = ?`,
        [data.name, cuisineId, mealId, data.rating, data.time, unique.length, data.source_url, data.image_url, id]
      )
      await q('DELETE FROM recipe_ingredients WHERE recipe_id = ?', [id])
    } else {
      const result = await q(
        `INSERT INTO recipes (recipe_name, cuisine_id, mealtype_id, rating, recipe_time, max_ingredients, recipe_url, image_url)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [data.name, cuisineId, mealId, data.rating, data.time, unique.length, data.source_url, data.image_url]
      )
      recipeId = result.insertId
    }

    await q('INSERT INTO recipe_ingredients (recipe_id, ingredient_id) VALUES ?', [unique.map((x) => [recipeId, x])])
    return recipeId
  })
}

// ---------- catalog for the website's filters and pantry ----------

export async function getMeta() {
  // every meal type and cuisine in the database, in table order, named exactly as stored
  const mealRows = await query('SELECT mealtype_name AS v FROM mealtypes ORDER BY mealtype_id')
  const cuisineRows = await query('SELECT cuisine_name AS v FROM cuisines ORDER BY cuisine_id')
  const rows = await query(
    `SELECT c.category_name AS category, i.ingredient_name AS name
     FROM ingredients i
     JOIN ingredient_categories c ON c.category_id = i.category_id
     ORDER BY c.category_id, i.ingredient_name`
  )

  const ingredients = {}
  for (const { category, name } of rows) (ingredients[category] ||= []).push(name)

  const [{ maxMinutes }] = await query('SELECT COALESCE(MAX(recipe_time), 0) AS maxMinutes FROM recipes')
  const [{ maxIngredients }] = await query(
    `SELECT COALESCE(MAX(n), 0) AS maxIngredients
     FROM (SELECT COUNT(*) AS n FROM recipe_ingredients GROUP BY recipe_id) AS counts`
  )
  const ratings = [1, 2, 3, 4, 5] // the buttons "1★ & up" ... "5★ & up"

  return {
    meals: mealRows.map((m) => m.v),
    cuisines: cuisineRows.map((c) => c.v),
    ingredients,
    aliases: {}, // the database has no alias table any more
    ratings,
    limits: { maxMinutes: Number(maxMinutes), maxIngredients: Number(maxIngredients) },
  }
}

// Matching is case-insensitive: "garlic" -> "Garlic". Anything unknown is returned unchanged.
export async function canonicalIngredients(names) {
  const clean = [...new Set(names.map((n) => String(n).trim()).filter(Boolean))]
  if (!clean.length) return []
  const official = await query('SELECT ingredient_name AS name FROM ingredients WHERE LOWER(ingredient_name) IN (?)', [clean.map((n) => n.toLowerCase())])
  const canon = new Map() // lowercase typed name -> official name
  for (const { name } of official) canon.set(name.toLowerCase(), name)
  return [...new Set(clean.map((n) => canon.get(n.toLowerCase()) || n))]
}
