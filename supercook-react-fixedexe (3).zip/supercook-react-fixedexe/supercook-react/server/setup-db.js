// Database setup:   npm run db:setup      (safe to repeat; it never deletes your data)
//   1. creates the database named in .env (DB_NAME, default supercook_db) if it doesn't exist
//   2. loads database/supercook_db.sql, but ONLY when the database has no tables yet
//      (if you already imported it in phpMyAdmin, your data is left exactly as it is)
//   3. adds the extra table the website needs (user_pantry) from database/app_tables.sql
//   4. checks that the tables and columns match supercook_db.sql
//
//       npm run db:reset      DELETES the tables and loads supercook_db.sql again (new recipes, accounts gone).
//                             Use it after you change supercook_db.sql, or when setup says your tables are outdated.
import 'dotenv/config'
import fs from 'node:fs'
import mysql from 'mysql2/promise'

const DB = process.env.DB_NAME || 'supercook_db'
const RESET = process.argv.includes('--reset')
const read = (file) => fs.readFileSync(new URL(`../database/${file}`, import.meta.url), 'utf8')
// we create/select the database ourselves (from DB_NAME), so drop those lines from the .sql files
const withoutDbLines = (sql) => sql.replace(/^\s*(CREATE DATABASE|USE)\b.*$/gim, '')

// What the code needs from supercook_db.sql
const REQUIRED = {
  users: ['user_id', 'email', 'password'],
  ingredient_categories: ['category_id', 'category_name'],
  ingredients: ['ingredient_id', 'category_id', 'ingredient_name'],
  cuisines: ['cuisine_id', 'cuisine_name'],
  mealtypes: ['mealtype_id', 'mealtype_name'],
  recipes: ['recipe_id', 'recipe_name', 'cuisine_id', 'mealtype_id', 'rating', 'recipe_time', 'max_ingredients', 'recipe_url', 'image_url'],
  recipe_ingredients: ['recipe_id', 'ingredient_id'],
  favorite_recipes: ['user_id', 'recipe_id'],
}

const conn = await mysql
  .createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    charset: 'utf8mb4',
    multipleStatements: true,
  })
  .catch((err) => {
    console.error(`Could not connect to MySQL (${err.code || err.message}).`)
    console.error('Start MySQL (XAMPP / Laragon "Start") and check DB_HOST / DB_PORT / DB_USER / DB_PASSWORD in .env.')
    process.exit(1)
  })

// table -> Set of its columns, for the tables of this database
async function layout() {
  const [rows] = await conn.query('SELECT TABLE_NAME AS t, COLUMN_NAME AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ?', [DB])
  const tables = new Map()
  for (const { t, c } of rows) (tables.get(t) || tables.set(t, new Set()).get(t)).add(c)
  return tables
}

// what is missing compared with supercook_db.sql, e.g. ["recipes.recipe_time", "table cuisines"]
async function problems() {
  const tables = await layout()
  const out = []
  for (const [table, cols] of Object.entries(REQUIRED)) {
    if (!tables.has(table)) out.push(`table ${table}`)
    else for (const c of cols) if (!tables.get(table).has(c)) out.push(`${table}.${c}`)
  }
  return out
}

try {
  await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`)
  await conn.query(`USE \`${DB}\``)

  if (RESET) {
    // the account tables of the website point at users / ingredients, so they go first
    await conn.query('SET FOREIGN_KEY_CHECKS = 0; DROP TABLE IF EXISTS user_pantry, user_favorites; SET FOREIGN_KEY_CHECKS = 1;')
    await conn.query(withoutDbLines(read('supercook_db.sql'))) // it drops and recreates its own tables
    console.log(`Database "${DB}": tables deleted and supercook_db.sql loaded again`)
  } else {
    // Is the data already there (imported in phpMyAdmin, or by an earlier run)?
    const [[{ existing }]] = await conn.query(
      "SELECT COUNT(*) AS existing FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ('ingredients', 'recipes')",
      [DB]
    )
    if (Number(existing) > 0) {
      console.log(`Database "${DB}": tables already exist, so supercook_db.sql was not loaded (your data is untouched)`)
    } else {
      try {
        await conn.query(withoutDbLines(read('supercook_db.sql')))
        console.log(`Database "${DB}": supercook_db.sql loaded`)
      } catch (err) {
        if (err.code !== 'ER_TABLE_EXISTS_ERROR') throw err
        console.log(`Database "${DB}": partly imported already, left as it is`)
      }
    }
  }

  const bad = await problems()
  if (bad.length) {
    console.error(`\nThe tables in "${DB}" do not match database/supercook_db.sql. Missing: ${bad.join(', ')}`)
    console.error('This happens after supercook_db.sql was changed. To load the new version (this DELETES the old tables and accounts), run:')
    console.error('    npm run db:reset')
    process.exitCode = 1
  } else {
    await conn.query(withoutDbLines(read('app_tables.sql')))

    const [[c]] = await conn.query(
      `SELECT (SELECT COUNT(*) FROM ingredients) AS ingredients,
              (SELECT COUNT(*) FROM recipes) AS recipes,
              (SELECT COUNT(*) FROM recipe_ingredients) AS links,
              (SELECT COUNT(*) FROM recipes WHERE recipe_url IS NOT NULL AND recipe_url <> '') AS linked,
              (SELECT COUNT(*) FROM recipes WHERE image_url IS NOT NULL AND image_url <> '') AS photos`
    )
    console.log(`\nReady: ${c.recipes} recipes (${c.linked} with a recipe link, ${c.photos} with a photo), ${c.ingredients} ingredients, ${c.links} recipe-ingredient links.`)
    console.log('Next:  npm run api   (then in a second window: npm run dev)')
    console.log('Add dish photos at  http://localhost:3001/admin  (see README-backend.md)')
  }
} catch (err) {
  console.error(`\nSetup failed: ${err.code || ''} ${err.sqlMessage || err.message}`)
  process.exitCode = 1
} finally {
  await conn.end()
}
