# SuperCook: find recipes from the ingredients you have

React website (`src/`) + Node/Express API (`server/`) + MySQL database (`database/`).
Full instructions, endpoints and the checklist of things to verify: **README-backend.md**

Quick start (PowerShell, inside this folder, MySQL running in XAMPP/Laragon):

    npm install
    npm run db:setup     # once: creates database "supercook_db" and loads all data
    npm run api          # window 1: API on http://localhost:3001
    npm run dev          # window 2: website on http://localhost:5173
