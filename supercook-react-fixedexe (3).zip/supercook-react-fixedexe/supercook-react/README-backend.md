# SuperCook: database, API and outside recipe search

The website is `src/`. The API is `server/`. The database files are `database/`.

## Run it (Windows PowerShell, inside the folder with package.json; MySQL started in XAMPP or Laragon)

```powershell
npm install
npm run db:setup       # once (safe to repeat): creates database "supercook_db", loads database/supercook_db.sql (only if the database is still empty),
                       # adds the saved-pantry table and checks the tables match supercook_db.sql
npm run db:reset       # after you CHANGE supercook_db.sql: deletes the tables and loads the new file (accounts and saved pantries are lost)
npm run api            # starts the API on http://localhost:3001   (keep this window open)
npm run dev            # in a SECOND window: starts the website
```

Check in the browser: http://localhost:3001/api/health  (should say `"database":"connected"`),
then http://localhost:3001/api/recipes and http://localhost:3001/api/meta

`.env` must say `DB_NAME=supercook_db` (already set). XAMPP default is user `root`, empty password.
If your MySQL has a password, put it in `DB_PASSWORD`.

## What the website shows comes from the database

Nothing is hard-coded in the website any more. On load it calls `/api/recipes` and `/api/meta` and builds:
the pantry list (ingredients grouped by their category name), Meal Type, Cuisines, the Max Ingredients slider
(top = most required ingredients in any recipe), the Recipe Time slider (top = longest recipe), and the Rating
buttons (only ratings that exist). Add a recipe or ingredient in MySQL and it appears after a page refresh.
Only the Exclude filter is a free ingredient search. If the API/database is off, the page says so instead of showing fake data.

## How the database is used

| Table (from supercook_db.sql) | Used for |
|---|---|
| ingredient_categories / ingredients | the pantry sidebar (ingredients grouped by category name) |
| cuisines / mealtypes | the Cuisines and Meal Type filters (every row of the tables is listed, in table order) |
| recipes / recipe_ingredients | recipe search; `recipe_time` = Recipe Time slider, `rating` = Rating filter, `recipe_url` = the recipe link, `image_url` = the dish photo |
| users, favorite_recipes | accounts (email + password hash) and favorites |
| user_pantry (from app_tables.sql) | the saved pantry of a logged-in user |

Notes about the schema:
- `users` only has `email` and `password`, so you log in with your **email**, and the name shown on the website is the part before the `@`
  (the register form no longer asks for a username).
- There are no ingredient aliases, quantities, units or optional flags in the database, so every ingredient of a recipe counts as required and
  the recipe pop-up lists ingredient names only. Instructions are not stored: the recipe link goes to them.
- `rating` is 0 to 5 with decimals. The rating buttons are always 1★ to 5★ & up (a 4.6 recipe shows under 1-4★ & up, not 5★ & up).
- `recipes.max_ingredients` is kept in sync by the API when you add or edit a recipe. If you add `recipe_ingredients` rows by hand run
  `UPDATE recipes r SET max_ingredients = (SELECT COUNT(*) FROM recipe_ingredients ri WHERE ri.recipe_id = r.recipe_id);`

Matching rules: recipes are ordered by the share of their ingredients you have. Excluding an ingredient hides recipes that use it.
The rating filter hides unrated recipes.

## Dish photos and recipe links

Every recipe card shows its photo (`recipes.image_url`) and falls back to the emoji when there is none. The recipe pop-up has a button that
opens the recipe page (`recipes.recipe_url`) in a new tab.

To add photos: 1) register an account on the website, 2) put its email in `ADMIN_EMAILS` in `.env`, 3) restart `npm run api`, 4) open
**http://localhost:3001/admin**, log in, and for each recipe press *Upload photo* (JPEG, PNG, WebP or GIF, up to 5 MB) or paste a picture link.
The same page edits the recipe link. Uploaded files are saved in `server/uploads/` and `image_url` holds `/uploads/<file>`; the API turns that into a
full address for the website. You can also fill `image_url` / `recipe_url` directly in phpMyAdmin (any https:// link).

## The outside recipe API

`GET /api/search` looks in your database first. If fewer than 8 recipes match, it asks an outside service and
merges the results (same shape as your own recipes, with a link back to the source). Results are remembered
for `EXTERNAL_CACHE_HOURS` (default 1). If the service is down or blocked, search quietly returns your own recipes.

| `EXTERNAL_PROVIDER` in .env | What happens |
|---|---|
| `auto` (default) | Spoonacular if `SPOONACULAR_KEY` is set, otherwise TheMealDB |
| `themealdb` | TheMealDB, no signup. Uses their public test key `1`: fine for development. For a public site get your own key and set `THEMEALDB_KEY`. No cooking time or rating in their data. |
| `spoonacular` | needs a free key from https://spoonacular.com/food-api in `SPOONACULAR_KEY`. Includes time and score. |
| `none` | database recipes only |

Test it:  `npm run api:check`  or  `npm run api:check -- Chicken Garlic`
`/api/health` shows which provider is active (`externalSearch`).

## Accounts, pantry and favorites

The login form talks to the API (register with email + password, log in with the email).
While logged in, your pantry is saved to your account and favorites are saved for recipes that are in your
database (table favorite_recipes); favorites of outside recipes stay in this browser. On login, what is in the browser and in the account is merged.

## Endpoints (all start with /api)

| Method | Path | Login | What it does |
|---|---|---|---|
| GET | /health | no | API, database and outside-search status |
| POST | /register | no | `{ email, password }` -> `{ username, token }` |
| POST | /login | no | `{ email, password }` -> `{ username, token }` |
| GET | /me | yes | who am I |
| GET | /recipes, /recipes/:id | no | recipes with ingredients, quantities |
| GET | /meta | no | `{ meals, cuisines, ingredients (by category), ratings, limits }` |
| GET | /search | no | `?pantry=Chicken,Garlic&exclude=&meal=&cuisine=&maxIng=&time=&rating=&external=0` -> `[{ r, have }]` |
| POST, PUT, DELETE | /recipes, /recipes/:id | admin | see below |
| POST, PUT, DELETE | /recipes/:id/image | admin | POST: the picture itself as the body (`Content-Type: image/jpeg` ...); PUT: `{ image_url }`; DELETE: remove |
| GET, PUT, DELETE | /pantry | yes | read / replace (`{ items: [...] }`) / empty the saved pantry |
| POST, DELETE | /pantry/:name | yes | add / remove one ingredient |
| GET | /favorites | yes | favorite recipe names |
| POST, DELETE | /favorites/:name | yes | add / remove a favorite |

Admin recipe body (POST, or PUT with every field except the photo, which is kept unless you send `image_url`):

```json
{ "name": "Garlic Rice", "meal": "Dinner", "cuisine": "Filipino",
  "ingredients": ["Garlic", "Rice", "Spring onions"],
  "time": 15, "rating": 4.5, "source_url": "https://example.com/garlic-rice", "image_url": "" }
```
Ingredient names that don't exist yet are added under *Specialty and Regional Ingredients*; new meal types and cuisines are added to their tables.

Send the token as `Authorization: Bearer <token>`.

## Before putting it online

- Make a new `JWT_SECRET` (command in `.env.example`); `.env` is in `.gitignore`.
- Set `CLIENT_ORIGIN` to your website's address, and `VITE_API_URL` when building the website.
- Get your own TheMealDB / Spoonacular key and check their terms before raising `EXTERNAL_CACHE_HOURS`.
