-- Extra table the website/API needs on top of supercook_db.sql.
-- supercook_db.sql already provides users (email + password), favorite_recipes, recipes, recipe_ingredients,
-- ingredients, ingredient_categories, cuisines and mealtypes.
-- This file only adds the saved pantry of a logged-in user (it points at users.user_id and ingredients.ingredient_id).
-- Safe to run more than once. Applied automatically by:  npm run db:setup
-- (No CREATE DATABASE / USE here: setup-db.js selects the database named in .env.)

CREATE TABLE IF NOT EXISTS user_pantry (
  user_id       INT UNSIGNED NOT NULL,
  ingredient_id INT UNSIGNED NOT NULL,
  added_at      TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, ingredient_id),
  KEY idx_user_pantry_ingredient (ingredient_id),
  CONSTRAINT fk_user_pantry_user FOREIGN KEY (user_id)
    REFERENCES users (user_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_user_pantry_ingredient FOREIGN KEY (ingredient_id)
    REFERENCES ingredients (ingredient_id) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
